import random
import re
import pandas as pd
import nltk
from nltk.stem.porter import PorterStemmer
from nltk.corpus import stopwords

class PreProcess:

    def __init__(self, filename: str = "reviews.csv"):
        """
        Initialise all instance variables.
        """
        # Invoke the pre_process_reviews function to get a list of review_corpus and a list of review locations
        review_corpus, locations = self.pre_process_reviews(filename)
        # Initialise instance variables with corresponding data
        self.reviews = review_corpus
        self.locations = locations
        
    def remove_special_characters(self, raw_review: str) -> str:
        """
        Remove special characters and numbers.
        Implements the re module: https://docs.micropython.org/en/latest/library/re.html

        Arguments: 
            - raw_reviews: an unprocessed raw review.

        Returns:
            - review: A review with special characters removed. 
        """
        # Replace every character in raw_review with ' ' if the character is not from A-Z and a-z
        review = re.sub("[^A-Za-z]", " ", raw_review)
        # Replace every repeated spaces in review with ' ', and remove leading and trailing spaces
        review = re.sub(' +', ' ', review).strip()
        return review

    def convert_lowercase(self, review: str) -> str:
        """
        Converts every character in the review to a lowercase character.

        Arguments:
            - review: A single customer review string (sentence in form of string). 

        Returns:
            - review: A review string with all characters in lowercase. 
        """
        return review.lower()

    def tokenize_reviews(self, review: str) -> list:
        """
        Splits the review into individual words. 

        Arguments:
            - review: A single customer review (sentence in form of string). 

        Returns:
            - review_tokens: A list of every words from a review.   
        """
        return review.split()

    def remove_stopwords(self, review_tokens: list) -> list:
        """
        Checks to see if there are any stopwords in each review and removes them. 
        A list of stopwords can be found in the documentation for the library of your choosing.
        Please extend the list of stopwords with custom_stopwords = ["due", "all", "on", "to"].

        Arguments:
            - review_tokens: A list of every words from a review. 

        Returns:
            - review_tokens: A list of every words from a review excluding stopwords.
        """
        # Initialise custom stopword 
        custom_stopwords = ["due", "all", "on", "to"]

        # Create a list stops with english stopwords and custom_stopwords
        stops = list(stopwords.words('english')) + custom_stopwords

        # Remove words from review_tokens list if the word appears in stops
        review_tokens = [token for token in review_tokens if token not in stops]
        
        return review_tokens

    def stem_words(self, review_tokens: list) -> str:
        """
        Stems all words in every review by removing affixes (eg: hopp(ing) -> hop).
        Implements the PorterStemmer module: https://www.nltk.org/howto/stem.html

        Arguments:
            - review_tokens: A list of every words from a review. 

        Returns:
            - review: A review with all words stemmed.
        """
        # Create a PorterStemmer instance
        ps = PorterStemmer()
        # Stem every word in the review_tokens list using PorterStemmer function
        # and join every word in the result lists using ' ' to form a string
        review_tokens = ' '.join([ps.stem(token) for token in review_tokens])
        
        return review_tokens

    def check_repeated_char(self, string: str) -> bool:
        """
        A helper function for remove_spam that uses recursion to check whether a string has repeated characters.
        
        Arguments :
            - string - A string of characters

        Returns :
            - bool: True if the string has all repeated characters, False otherwise
        """
        # Remove all special characters in the string and convert it to lowercase
        string = self.remove_special_characters(string)
        string = self.convert_lowercase(string)

        # If the string contains nothing or contains only 1 character, return True
        if len(string) < 2:
            return True
        # Else if the first char and second char of the string are the same, recurse the string started from the second character.
        elif string[0] == string[1]:
            return self.check_repeated_char(string[1:])
        # If the second char of the string is ' ', recurse the string by removing the second character.
        elif string[1] == ' ':
            return self.check_repeated_char(string[0] + string[2:])
        # Else, which means the first char and the second char of the string are not equal and the second char is not ' ', return False
        else:
            return False

    def remove_spam(self, review_corpus: list, locations: list) -> tuple:
        """
        Removes spam reviews in the form of repeated characters such as "aaa aa" or "b b b bbbbb".
        Removes locations of those spam reviews from locations.

        Arguments :
            - review_corpus : A list of words
            - locations : A list of location 

        Returns :
            - review_corpus: A list containing pre-processed customer reviews after the spam reviews are removed.
            - locations: A list containing locations after the locations for the spam reviews are removed.
        """
        # Create an empty list to store the index of the element to be removed from the locations list
        to_be_removed = []

        # Create a copy of review_corpus
        review_corpus_copy = review_corpus[:]

        # Loop through every review in review_corpus_copy list
        for review in review_corpus_copy:
            # Pass the review to check_repeated_char function, if it returns True, which means that the review is formed by many repeated characters
            if self.check_repeated_char(review):
                # Remove the review from the original review_corpus list
                review_corpus.remove(review)
                # Get the index of the review from the review_corpus_copy list, the index represents the corresonding index in the locations list
                index = review_corpus_copy.index(review)
                # Appends the index to the to_be_removed list
                to_be_removed.append(index)
        
        # Loop through to_be_removed list in reversed to prevent error deleting
        for index in reversed(to_be_removed):
            # Remove the location with the particular index from locations list
            del locations[index]

        return review_corpus, locations

    def pre_process_reviews(self, filename: str = "reviews.csv") -> tuple:
        """
        Combines all functions created above to pre-process reviews from the file reviews.csv.
        - Read file to extract raw reviews then;
        - Iterate through raw reviews to pre-process reviews following the order:
             1. Remove special characters 
             2. Convert review to lowercase then tokenise each review
             3. Remove any stop words before stemming words in each review
        - Remove spam before returning review_corpus.

        Arguments : 
            - filename : A string of filename which is default as "reviews.csv"

        Returns :
            - review_corpus: A list that contains every review after pre-processing. 
            - locations: A list containing locations for the reviews in review_corpus.
        """
        # Read file using pandas, using '\t' as separators
        data = pd.read_csv(filename, sep='\t')
        # Get the locations and raw_reviews list from data
        locations = data['Country'].tolist()
        raw_reviews = data['Review'].tolist()
        # Create an empty list for pre_processed reviews
        review_corpus = []

        # loop every review from raw_reviews
        # first remove special characters, then convert to lowercase
        # tokenize review to review_tokens, then remove stopwords and stem words
        # finally append to review_corpus

        # Loop through every index in the range of len(locations)
        for index in range(len(locations)):
            # Get the particular review
            review = raw_reviews[index]
            # Remove special characters from the review, convert it to lowercase, then split the review into review_tokens list
            review = self.remove_special_characters(review)
            review = self.convert_lowercase(review)
            review_tokens = self.tokenize_reviews(review)
            # Remove stopwords from the list and stem every word in the list to get the processed_review string
            review_tokens = self.remove_stopwords(review_tokens)
            processed_review = self.stem_words(review_tokens)
            # Append the processed_review to the review_corpus list
            review_corpus.append(processed_review)

        # Remove spam reviews and their correspond locations in the review_corpus and locations lists
        review_corpus, locations = self.remove_spam(review_corpus, locations)
        return review_corpus, locations

    def assign_review_location(self, review_corpus: list, locations: list) -> dict:
        """
        Assign each review to the appropriate franchise location.

        Arguments : 
            - review_corpus : a list of review
            - locations : a list of loaction

        Returns :
            - reviews_with_locations : A dictionary with locations as keys with a corresponding 
            value of a dictionary of all reviews from those locations indexed by csv file row.
        """
        # Create an empty dictionary
        reviews_with_locations = {}

        # Loop through every location in locations list and assign them into a dictionary with location as key, review as value 
        for i in range(len(locations)):
            # If the current location is not in the reviews_with_locations dictionary
            if locations[i] not in reviews_with_locations:
                # Using the location as key, create another dictionary as value, store them inside the reviews_with_locations dictionary
                # The new dictionary is formed by looping through every index j in the review_corpus list
                # Then if current location (locations[i]) is the same as locations[j]
                # Use the index j as key, review as value, store them in the new dictionary
                reviews_with_locations[locations[i]] = {j: review_corpus[j] for j in range(len(review_corpus)) if locations[j] == locations[i]}
        return reviews_with_locations
        
    def generate_new_reviews(self, review_corpus: list, starters: list, features: list, linking_verbs: list, adjectives: list, num: int = 4) -> list:
        """
        Take in an existing review_corpus and extending it to include /num/ new reviews. /num/ is set to 4 by default.
        
        Generates new reviews by randomly selecting and combining the sentences of the input parameters.
        
        For example, if we use:
            starters = ["In my opinion", "To me", "Honestly"]
            features = ["occupancy", "menu items", "opening hours", "staff"]
            linking_verbs = ["is", "are", "was", "were"]
            adjectives = ["insufficient", "not enough", "inadequate", "short"]
        
        [2, 0, 2, 0] forms "Honestly occupancy was insufficient"
        [1, 3, 3, 2] forms "To me staff were not enough"

        Arguments : 
            - review_corpus : A list of review
            - starters : A list of starting words of sentence
            - features : A list of featured words of sentence
            - linking_verbs : A list of linking verbs of sentence
            - adjectives : A list of adjectives of sentence
            - num : An integer which is default as 4

        Returns :
            - review_corpus: A list containing pre-processed customer reviews after the new reviews are inserted.
        """
        # Loop for num times
        for count in range(num):
            # Ramdomly choose a word from starters, features, linking_verbs, adjectives to form a sentence and append to review_corpus list
            first = random.choice(starters)
            second = random.choice(features)
            third = random.choice(linking_verbs)
            fourth = random.choice(adjectives)
            review_corpus.append(first + ' ' + second + ' ' + third + ' ' + fourth)

        return review_corpus
