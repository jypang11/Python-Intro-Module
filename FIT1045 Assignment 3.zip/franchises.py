from restaurants import Restaurant, Menu
import random
import math

class FranchiseMenu(Menu):

    def __init__(self) -> None:
        """
        Initialise Franchise Menu object using inheritance.
        """
        super().__init__()
        self.location = ""

    def get_national_dishes(self, filename: str = 'national_dishes.txt') -> dict:
        """
        Read filename and extract all the national dishes from it.

        Returns:
            - national_dishes: Dictionary with a country as the key and it's corresponding national dish(s) as the value.
        """
        # Read file
        with open(filename, "r") as dishes_file:
            # Extract every line in the file
            lines = dishes_file.readlines()

            # Use this for loop get the start_index, which represents the index of the line where we wants to start extracting menu details
            for index in range(len(lines)):
                if "===" in lines[index]:
                    start_index = index
                    break
            # Slice the lines list from start_index line to the last line
            lines = lines[start_index:]

            # Extract the keys and values from every line in lines list
            # which we first split the line using ': ' into 2 elements, then the keys are all the first elements
            keys = [line.split(': ')[0].strip() for line in lines if ": " in line]
            # All the second elements after splitting the line are the values, which represents the dishes
            # We then split the dishes using ', ', and store all the dishes as a list
            # At the end we will have a list of lists, values
            values = [[element.strip() for element in line.strip().split(': ')[1].split(', ')] for line in lines if ': ' in line]
            
            # Using every element in keys as keys, every element in values as values, store them in national_dishes dictionary
            national_dishes = {keys[i]: values[i] for i in range(len(keys))}
            
            return national_dishes
        
    def get_national_drinks(self, filename: str = 'national_drinks.txt') -> dict:
        """
        Read filename and extract all the national drinks from it.

        Returns:
            - national_drinks: Dictionary with a country as the key and it's corresponding national drink(s) as the value.
        """
        # Read file
        with open(filename, "r") as drinks_file:
            # Extract every line in the file
            lines = drinks_file.readlines()
            # Use this for loop get the start_index, which represents the index of the line where we wants to start extracting menu details
            for index in range(len(lines)):
                if "==" in lines[index]:
                    start_index = index
                    break
            # Slice the lines list from start_index line to the last line
            lines = lines[start_index:]
            
            # Extract the keys and values from every line in lines list
            # which we first split the line using ': ' into 2 elements, then the keys are all the first elements
            keys = [line.split(': ')[0].strip() for line in lines if ': ' in line]
            # All the second elements after splitting the line are the values, which represents the drinks
            # We then split the drinks using ', ', and store all the drinks as a list
            # At the end we will have a list of lists, values
            values = [[element.strip() for element in line.strip().split(': ')[1].split(', ')] for line in lines if ': ' in line]
            
            # Using every element in keys as keys, every element in values as values, store them in national_dishes dictionary
            national_drinks = {keys[i]: values[i] for i in range(len(keys))}
            
            return national_drinks

    def update_franchise_menu(self, dishes: list, drinks: list, location: str) -> None:
        """
        Update Franchise Menu attributes based on the following guidelines:

        Receive dishes and drinks list, and location from input parameters.
        
        Create a drinks_prices list where the drinks are randomly priced between RM 0.50 to 15.99.
        
        Then create a dishes_prices list where the drinks are randomly priced between RM 5.00 to 75.99.
        
        Set the dishes, drinks and location attribute accordingly.
        """
        """
        A function to update menu.

        Arguments : 
            - dishes : A list of dishes.
            - drinks : A list of drinks.
            - location : A list of locations.
        """
        # Randomly generate price for every dishes and drinks, store them in dishes_prices and drinks_prices, respectively
        drinks_prices = ["{:.2f}".format(random.uniform(0.50, 15.99)) for i in range(len(drinks))]
        dishes_prices = ["{:.2f}".format(random.uniform(5.00, 75.99)) for i in range(len(dishes))]
        # Invoke the set_dishes and set_drinks function from super class
        self.set_dishes(dishes, dishes_prices)
        self.set_drinks(drinks, drinks_prices)
        
        # Set location
        self.location = location
        
class Franchise(Restaurant):

    def __init__(self, location: str, franchise_menu: FranchiseMenu) -> None:
        """
        Initialise and update Franchise attributes based on the guidelines:
        
        - 50-50% chance of either:
          Keeping the default restaurant name ("A Slice of Py"),
          or randomly choosing between the options of "Py's Restaurant", "1045 Py Bistro", "Slice of Py", "A Slice of Py Bistro" or "Py 1045";
          
        - 50-50% chance of either:
          Keeping the default opening and closing times of 08:00 and 22:00, or randomly choosing opening
          times and closing times between 08:00-13:00 and 18:00-23:00, respectively;

        - Set the appropriate number of staff accordingly.
          There should be 6 to 10 kitchen staff and 1 waiter is needed for every 10 available seats.
          e.g. an occupancy of 18 may lead to 7 kitchen staff + 2 waiters = 9 staff;
          
        - Set the restaurant's occupancy (available seats) to a randomly generated number between 15 to 35;
          
        - Set the net worth to a randomly generated value between 50000 to 200000;
        
        - Set the franchise menu to the newly created FranchiseMenu object;
        
        - Set the location and menu according to input parameters.
        """
        # Invoke the super class's constructor
        super().__init__(franchise_menu)

        # If a randomly generated number between 0 and 1 is >= 0.5, randomly set the restaurant_name between various new names.
        if random.random() >= 0.5:
            self.set_restaurant_name(random.choice(["Py's Restaurant", "1045 Py Bistro", "Slice of Py", "A Slice of Py Bistro", "Py 1045"]))
        
        # If a randomly generated number between 0 and 1 is >= 0.5
        # randomly set the opening times and closing times between 08:00-13:00 and 18:00-23:00, respectively
        if random.random() >= 0.5:
            opening_hour, closing_hour = random.randint(8, 13), random.randint(18, 23)
            opening_time = f"0{opening_hour}:00" if opening_hour < 10 else f"{opening_hour}:00"
            closing_time = f"{closing_hour}:00"
            self.set_restaurant_hours(opening_time, closing_time)

        # Initialise franchise restaurant occupancy to a random integer between 15 and 35
        self.set_occupancy(random.randint(15, 35))

        # Initialise franchise restaurant number of staff according to the conditions
        self.set_number_of_staff(random.randint(6, 10) + math.ceil(self.occupancy / 10))
        
        # Initialise franchise restaurant net worth to a random integer between 50000 and 200000
        self.set_net_worth(random.randint(50000, 200000))
        
        # Initialise franchise restaurant location
        self.location = location

def create_menu_and_restaurant_instances() -> tuple:
    """
    1. Dynamically creates instances of FranchiseMenu with national_dishes, national_drinks, and locations.
    2. Dynamically creates instances of Franchise. 

        Returns:- 
        - locations: A list of countries that are present in both national_dishes and national_drinks.
        - franchises: A list of franchise instances. 
        - franchise_menus: A list of franchise_menu instances. 
    """
    # Create a FranchiseMenu instance
    franchise_menu = FranchiseMenu()

    # Invoke get_national_dishes and get_national_drinks functions to get national_dishes and national_drinks dictionaries
    national_dishes = franchise_menu.get_national_dishes()
    national_drinks = franchise_menu.get_national_drinks()
    # Create three different empty lists for following variables
    franchise_menus, franchises, franchise_locations = [], [], []

    # For every k, v in national_dishes.items(), which k and v represents location and dishes, respectively
    for k, v in national_dishes.items():
        # If the location(k) is also in national_drinks
        if k in national_drinks:
            # Create a new FranchiseMenu instance
            franchise_menu = FranchiseMenu()
            # Update the franchise_menu of the particular franchise with dishes list(k), drinks list(national_drinks[k]) and location(k)
            franchise_menu.update_franchise_menu(v, national_drinks[k], k)
            # Append the particular franchise_menu to the franchise_menus list
            franchise_menus.append(franchise_menu)
            # Append the location k to the franchise_locations list
            franchise_locations.append(k)
            # Create Franchise instance using location and franchise_menu and append it to the franchises list
            franchises.append(Franchise(k, franchise_menu))

    return (franchise_locations, franchises, franchise_menus)
