from preprocess import *
from nltk.sentiment.vader import SentimentIntensityAnalyzer
        
class FeatureExtractor:
    
    def extract_common_words(self, reviews: list, num: int = 15) -> list:
        """
        Extracts the top num occuring words from a list of reviews. 
        num is set to 15 by default.

        Arguments:
            - reviews: A list of pre-processed customer reviews. 

        Returns:
            - common_words: A list of tuples containing the word and the number of occurence.
        """
        # Join every review in reviews list, then split them to get a list of words
        words = ' '.join(reviews).split()
        # Generate a dictionary with every word in words as key, and the count of the word in words list as value
        counts = {word: words.count(word) for word in words}
        # Generate a list of tuple where the tuple is the key, value pair in counts dictionary
        common_words = [(k, v) for k, v in counts.items()]
        # Sort the common words list where the sort key is the second element in the tuple (which is count of the word), in reversed form
        common_words.sort(key=lambda x: x[1], reverse=True)
        
        # Return the first num element in the common_words list
        return common_words[:num]

class ReviewSummariser:

    def calculate_word_weights(self, review: str, words_to_ignore: list) -> dict:
        """
        Determines the weight of each word in a review by counting it's occurence and dividing the total occurences with the highest frequency. 

        Arguments:
            - review: An individual review.
            - words_to_ignore: A list that consists of words to ignore (weight of word will be 0).

        Returns:
            - weighted_words: A dictionary containing the weights of every word in the review. 
        """
        
        # Create a PreProcess instance
        p = PreProcess()
        # Remove special characters in review, convert the review to lowercase, and split the review to a list of words
        clean_review = p.convert_lowercase(p.remove_special_characters(review))
        words = p.tokenize_reviews(clean_review)
        # Generate a dictionary where the key is every word in words list
        # The value of the key is the count of the word in words list if the word is not in the words_to_ignore list
        # If the word is in the words_to_ignore list, set the value of the key as 0
        counts = {word: words.count(word) if word not in words_to_ignore else 0 for word in words}
        # Generate the greatest count among all word counts in counts dictionary
        most_word_count = max(counts.values())
        # Generate another dictiory where the key is every word in words
        # The value of the key is the the count of the words generated in the counts dictionary divided by the most_word_count
        weighted_words = {word: counts[word]/most_word_count for word in words}
        # Return the weighted_words dictionary
        return weighted_words

    def calculate_sentence_weights(self, review: str, selected_words: dict, words_to_ignore: list) -> dict:
        """
        Determines the weight of each sentence by adding weighted frequencies of the words that occur in that particular sentence.

        Arguments:
            - review: An individual review.
            - selected_words: A dictionary that stores extra weight to priotise certain words.
            - words_to_ignore: A list that consists of words to ignore (weight of word will be 0).

        Returns:
            - weighted_sentences: A dictionary containing the weights of every sentence in the review. 
        """
        # Create a Preprocess instance
        p = PreProcess()
        # Generate weighted_words dictionary using the calculate_word_weights function
        weighted_words = self.calculate_word_weights(review, words_to_ignore)
        
        # Generate a list of sentences
        sentences = [sentence.strip() for sentence in review.split('.') if sentence != ""]
        # Create an empty dictionary
        weighted_sentences = {}

        # Loop through every sentence in sentences list
        for sentence in sentences:
            # Remove special characters, convert the sentence into lowercase and split the sentence to a list of words
            clean_sentence = p.convert_lowercase(p.remove_special_characters(sentence))
            words = p.tokenize_reviews(clean_sentence)
            # Set the sentence_weight to 0 which represents the weight of the sentence
            sentence_weight = 0
            # For every word in words in sentence
            for word in words:
                # Add the weight of the word to the sentence_weight
                sentence_weight += weighted_words[word]
                # If the word is in selected_words and not in words_to_ignore
                if word in selected_words and word not in words_to_ignore:
                    # Add the additional weight for selected_words to the sentence_weight
                    sentence_weight += selected_words[word]
            # Using the sentence as key, the sentence_weight as value, store them inside the weighted_sentences dictionary
            weighted_sentences[sentence] = sentence_weight
        return weighted_sentences

    def generate_summary(self, review: str, n: int, selected_words: list, words_to_ignore: list) -> str:
        """
        Generates a summary of a review by taking the top n sentences with the highest scores.

        Arguments:
            - review: An individual review.
            - n: An integer representing how many sentences should be combined.
            - selected_words: A dictionary that stores extra weight to priotise certain words.
            - words_to_ignore: A list that consists of words to ignore (weight of word will be 0).

        Returns:
            - review_summary: A summary of a review. 
        """
        # Generate the weighted_sentences dictionary using the calculate_sentence_weights function
        weighted_sentences = self.calculate_sentence_weights(review, selected_words, words_to_ignore)
        # Sort the weighted_sentences dictionary
        # Firstly, in weighted_sentences.items(), using the second element of the tuple as key, sort the iterable in reversed
        # Then, convert the sorted iterable back to dictionary
        sorted_weighted_sentences = dict(sorted(weighted_sentences.items(), key=lambda x: x[1], reverse=True))
        
        # If the argument n is greater than the length of dictionary keys, set n to the length of the dictionary keys
        if n > len(sorted_weighted_sentences.keys()):
            n = len(sorted_weighted_sentences.keys())
        
        # Generate a list of sorted_weighted_sentences keys and slice it to the first n elements
        sentences = list(sorted_weighted_sentences.keys())[:n]
        # Concatenate every sentence in sentences with a full stop '.'
        sentences = [sentence + '.' for sentence in sentences]
        # Join every sentence in sentences with a space ' '
        review_summary = ' '.join(sentences)
        return review_summary

class SentimentAnalyser:

    def get_customer_sentiment(self, reviews: list) -> list:
        """
        Determines the sentiment possibilities of every review.
        Implements Sentiment Analysis from the NLTK module: https://www.nltk.org/howto/sentiment.html

        Arguments:
            - reviews: A list of pre-processed customer reviews. 

        Returns:
            - sentiments: A list containing dictionaries of review sentiments which consists of compound, negative, neutral, and positive probablities.  
        """
        # Create a SentimentIntensityAnalyzer instance
        sid = SentimentIntensityAnalyzer()
        # Generate sentiment for every review in reviews and store them in the sentiments list
        sentiments = [sid.polarity_scores(review) for review in reviews]
        return sentiments

    def insert_customer_sentiment(self, reviews: list, locations: list) -> tuple:
        """
        Determines the sentiment of every review depending on the highest probability and sets the sentiment to: (0:Negative, 1:Positive, 2:Neutral)

        Arguments:
            - reviews: A list of pre-processed customer reviews (follow csv file order).
            - locations: A list of all franchise locations (follow csv file order). 

        Returns:
            - compounds: The compound rate of the review. 
            - reviews_with_locations_sentiments: A nested dictionary containing lists that consists of the customer's reviews and the sentiment (0, 1, or 2).
        """
        # Create a dictionary to represent (Negative: 0, Positive: 1, Neutral: 2)
        sentiment_category = {'neg': 0, 'pos': 1, 'neu': 2}
        # Generate sentiments using the get_customer_sentiment function
        sentiments = self.get_customer_sentiment(reviews)
        # Generate a list of compounds from every sentiment in sentiments
        compounds = [sentiment['compound'] for sentiment in sentiments]

        # Create a PreProcess instance
        p = PreProcess()
        # Generate reviews_with_locations using the assign_review_location function from PreProcess class
        reviews_with_locations = p.assign_review_location(reviews, locations)
        # Create an empty dictionary to store reviews with locations and sentiments
        reviews_with_locations_sentiments = {}
        # Loop through every location and reviews_dict in the reviews_with_locations items
        for location, reviews_dict in reviews_with_locations.items():
            # Create an empty new dictionary
            new_dict = {}
            # Loop through every index and review in the reviews_dict items
            for index, review in reviews_dict.items():
                # Compute the sentiment for the particular index from sentiments list
                # Convert the sentiment dictionary to a list of tuples, and remove the last element (the compounds column)
                sentiment = list(sentiments[index].items())[:-1]
                # Using the first element of the tuple (the value for 'neg', 'neu' or 'pos') as key
                # Generate the max_key ('neg', 'neu' or 'pos') from the first element of the tuple
                max_key = max(sentiment, key=lambda x:x[1])[0]
                # Using the index as key, [review, sentiment_category] list as value, store them inside new_dict
                new_dict[index] = [review, sentiment_category[max_key]]
            # Using location as key, new_dict as value, store them inside reviews_with_locations_sentiments
            reviews_with_locations_sentiments[location] = new_dict
        return compounds, reviews_with_locations_sentiments
