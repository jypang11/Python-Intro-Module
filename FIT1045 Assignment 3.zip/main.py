from restaurants import *
from franchises import create_menu_and_restaurant_instances
from preprocess import *
from analyse_reviews import *
from visualise_data import *

from nltk.corpus import stopwords
from tabulate import tabulate
import pandas as pd
import random
import time

class Main:

    def __init__(self):
        """
        Initialise all instance variables.
        """
        # Initialise franchise_locations, franchises, franchise_menus from the create_menu_and_restaurant_instances function
        self.franchise_locations, self.franchises, self.franchise_menus = create_menu_and_restaurant_instances()

        # Create a PreProcess instance
        p = PreProcess()
        # Initialise reviews, review_locations and reviews_with_locations
        self.reviews = p.reviews
        self.review_locations = p.locations
        self.reviews_with_locations = p.assign_review_location(p.reviews, p.locations)

    def prompt_int_choice(self, choices: list, prompt: str = "") -> int:
        """
        A general function to prompt user to choose within various choice in choices list.

        Arguments:
            - choices: A list of available choices to be chosen by the user.
            - prompt: A string to be prompted when asking user to input their choice. It is set as "" by default.

        Returns:
            - choice: An integer which represents the index of the chosen choice in the choices list.
        """
        # Print out all available choices
        for i, element in enumerate(choices):
            print(f"[{i+1}] {element}")
        while True:
            # Try-except block to prevent invalid input from user
            try:
                # Prompt user to input and integer
                choice = int(input(prompt)) - 1
                while not (0 <= choice < len(choices)):
                    # Print error message while the number inputted is not in range
                    print("Must only choose a number in range given.")
                    choice = int(input(prompt)) - 1
                # Break the outer while loop
                break
            except ValueError:
                # Print error message
                print("You entered an invalid statement, please retry.")
            except KeyboardInterrupt:
                # Print error message
                print("\nYou entered an invalid statement, please retry.")
        return choice

    def prompt_int_input(self, prompt: str, num_range: tuple) -> int:
        """
        A general function to prompt user to input an integer number within the number range given.

        Arguments:
            - prompt: A string to be prompted when asking user to input an integer.
            - num_range: A tuple of 2 integers which represents the interval of desire number range.count
        
        Returns:
            - num: An integer within the number range given.
        """
        while True:
            # Try-except block to prevent invalid input from user
            try:
                # Prompt user to input an integer number
                num = int(input(prompt))
                # While the number is not within the required range
                while not (num_range[0] <= num <= num_range[1]):
                    # Print error message
                    print(f"The number should between {num_range[0]} to {num_range[1]}.")
                    num = int(input(prompt))
                break
            except ValueError:
                # Print error message
                print("You entered an invalid statement, please retry.")
            except KeyboardInterrupt:
                # Print error message
                print("\nYou entered an invalid statement, please retry.")
        return num

    def search_location(self, locations: list) -> str:
        """
        Prompt user to search and choose for a particular location in locations list.

        Arguments:
            - locations: A list of locations, note that the locations list should not have duplicate locations inside the list.

        Return:
            - chosen_location: A string of chosen location's name.
        """
        while True:
            # Prompt user to search a location
            search = input("Search a location: ")
            # Filter the locations to keep location if the term inputted is inside the location name
            filtered_locations = [location for location in locations if search.lower().strip() in location.lower()]
            # If the filtered_locations is empty
            n = 10
            for i in range(n):
                time.sleep(0.1)
                if i == 9:
                    print("\n")
                else:
                    print("Searching" + "."*i, end = "\r")
            if not filtered_locations:
                # Print error message
                print("No location found! Please try a different search term or enter nothing to choose within all available locations.")
                # Continue to the next loop to prompt for a new search term
                continue
            # Prompt user to choose a location between all filtered locations
            choice = self.prompt_int_choice(filtered_locations, "Please choose a franchise: ")
            # Compute the chosen_location from the choice
            chosen_location = filtered_locations[choice]
            return chosen_location

    def view_franchise_details(self) -> None:
        """
        A function to invoke self.search_location() function to let the user choose a desire franchise location.
        Then display that particular franchise location and its details.
        """
        # Print following message
        print("\n\nWhich franchise's details do you want to view?")
        # Prompy user to search a location among all franchise_locations
        franchise_location = self.search_location(self.franchise_locations)
        # Get the index of the franchise_location
        franchise_location_index = self.franchise_locations.index(franchise_location)
        # Get the chosen franchise instance
        franchise = self.franchises[franchise_location_index]
        # Print Franchise location
        print(f"\nFranchise Location: {self.franchise_locations[franchise_location_index]}")
        # Print franchise occupancy, staff and net worth details
        print(franchise)
        # Print franchise operating times, menu details
        franchise.display_details()

    def generate_new_reviews(self) -> None:
        # Create a PreProcess instance
        p = PreProcess()
        # Initialise starters, features, linking_verbs, adjectives
        starters      = ["In my opinion", "To me", "Honestly", "Certainly", "Obviously"]
        features      = ["occupancy", "menu items", "opening hours", "staff"]
        linking_verbs = ["is", "are", "was", "were"]
        adjectives    = ["insufficient", "not enough", "inadequate", "short", "more than enough", "sufficient"]

        # Prompt user to input the desire number of new reviews to generate
        num = self.prompt_int_input("How many new reviews do you want to generate? ", (1, 30))
        # Update the self.reviews instance variable with new reviews included
        self.reviews = p.generate_new_reviews(self.reviews, starters, features, linking_verbs, adjectives, num)

        print(f"Generated {num} new reviews!")
        # Loop num times
        for count in range(num):
            # Randomly choose one location among the franchise_locations for the new review
            location = random.choice(self.franchise_locations)
            # Append the self.review_locations instance variables with the new review location
            self.review_locations.append(location)
            # Get the index of the review
            index = len(self.review_locations) - 1
            # Print out the review with its locations
            print(f"{count+1}. {location}: {self.reviews[index]}")

        # Update the self.reviews_with_locations instance variables
        self.reviews_with_locations = p.assign_review_location(self.reviews, self.review_locations)

    def analyse_reviews(self) -> None:
        """
        A function to let user choose to analyse the reviews, by overall or by country.
        Then let the user to choose between various ways to analyse the reviews, by FeatureExtractor, by ReviewSummariser or by SentimentAnalyser.

        Arguments:
            - None.

        Returns:
            - None.
        """
        while True:
            # Prompt user to choose to analyse reviews between choices_1
            print("\n\nDo you want to analyse reviews by overall or by country?")
            choices_1 = ["By overall", "By country", "Back"]
            choice_1 = self.prompt_int_choice(choices_1)
            # If the choice_1 is 2 ("Back"), break the while loop
            if choice_1 == 2:
                break

            # Set the reviews, review_locations, reviews_with_locations with corresponding self instance variables
            reviews, review_locations, reviews_with_locations = self.reviews, self.review_locations, self.reviews_with_locations
            # If choice_1 is 0 ("By overall")
            if choice_1 == 0:
                # Let filtered_reviews and filtered_locations remains unchanged from reviews and review_locations
                filtered_reviews = reviews
                filtered_locations = review_locations
            # If choice_1 is 1 ("By country")
            elif choice_1 == 1:
                # Remove duplicates in review_locations
                locations = list(dict.fromkeys(review_locations))
                # Prompt user to search a location among locations
                chosen_location = self.search_location(locations)
                # Get the filtered_reviews_dict from the reviews_with_locations dict
                filtered_reviews_dict = reviews_with_locations[chosen_location]
                # Get the filtered_reviews from the values of filtered_reviews_dict
                filtered_reviews = list(filtered_reviews_dict.values())
                # Compute the filtered_locations len(filtered_reviews) number of chosen_location
                filtered_locations = [chosen_location] * len(filtered_reviews)
            
            # Prompt user to choose how to analyse the reviews between choices_2
            print("\n\nChoose 1 way to analyse the reviews: ")
            choices_2 = ["Feature Extractor", "Review Summariser", "Sentiment Analyser", "Back"]
            choice_2 = self.prompt_int_choice(choices_2)
            # Invoke corresponding functions with respective choices
            if choice_2 == 0:
                self.feature_extractor(filtered_reviews)
            elif choice_2 == 1 and choice_1 == 0:
                self.review_summariser()
            elif choice_2 == 1 and choice_1 == 1:
                self.review_summariser(chosen_location)
            elif choice_2 == 2:
                self.sentiment_analyser(filtered_reviews, filtered_locations)
            elif choice_2 == 3:
                continue
            break

    def feature_extractor(self, reviews: list) -> None:
        """
        A function to use FeatureExtractor class to extract common words of a list of reviews.
        Then ask the user to choose between various ways to visualise the common words.
        The common_words can be visualised by using generate_bar_chart() function, by printing a table in the console, or both.

        Arguments:
            - reviews: A list of reviews which can be overall reviews (reviews from all country) or reviews by country.
        
        Returns:
            - None.
        """
        # Compute the num_upper_bound by the minima between number of words in reviews and 15
        num_upper_bound = min(len(' '.join(reviews).split()), 15)
        # Prompt user to input an integer within the range
        num = self.prompt_int_input("How many common words do you wish to extract? ", (1, num_upper_bound))

        # Create a FeatureExtractor instance
        fe = FeatureExtractor()
        # Compute common_words using extract_common_words function
        common_words = fe.extract_common_words(reviews, num)

        # Prompt user to choose between various choices to visualise the common_words data
        print("\n\nHow do you want to visualise the corresponding data?")
        choices = ["Generate a table", "Generate a bar chart", "Both"]
        choice = self.prompt_int_choice(choices)
        # If choice is "Generate a table" or "Both"
        if choice in [0, 2]:
            # Create a pandas DataFrame
            df = pd.DataFrame(common_words, columns =['Word', 'Count'])
            print("\n\nGenerating a table...")
            time.sleep(2)
            # Print out the common_words as a table in the terminal using tabulate library with following attributes
            print(tabulate(df, headers='keys', tablefmt='fancy_grid', showindex=False))
        # If choice is "Generate a bar chart" or "Both"
        if choice in [1, 2]:
            print("\n\nGenerating a bar chart...")
            # Invoke the generate_bar_chart function
            generate_bar_chart(common_words)
            time.sleep(2)
            print("Generated a bar chart!")
    
    def review_summariser(self, chosen_location: str = "") -> None:
        """
        A function to use ReviewSummariser class to let the user summarise a number of longest raw reviews from reviews.csv,
        note that review_summariser does not summarise randomly generated reviews from generate_new_reviews function.        
        
        Arguments:
            - chosen_location: A string that will pass in if the user chose to analyse review by location, it is set as "" by default.

        Returns:
            - None.
        """
        # Create a PreProcess instance
        p = PreProcess()

        # Read csv file using pandas
        data = pd.read_csv("reviews.csv", sep='\t')
        # Get the raw_locations and raw_reviews
        raw_locations = data['Country'].tolist()
        raw_reviews = data['Review'].tolist()
        # Remove spam reviews and its locations from the lists
        raw_reviews, raw_locations = p.remove_spam(raw_reviews, raw_locations)
        
        # Create an empty list
        raw_sentences_reviews = []
        # Loop through every review in raw_reviews
        for review in raw_reviews:
            # Convert corresponding characters to '.' to form sentences
            review = re.sub("[!?.;:]+", '.', review)
            # Convert characters not in square bracket to ' ' to remove special characters
            review = re.sub("[^A-Za-z0-9,.' -]", " ", review)
            # Remove repeated, leading, and trailing spaces
            review = re.sub(' +', ' ', review).strip()
            # At this stage, the review should be clean with only a number of sentences and essential special characters only
            # Append the processed review to the raw_sentences_reviews list
            raw_sentences_reviews.append(review)
        # Replace the raw_reviews with raw_sentences_reviews
        raw_reviews = raw_sentences_reviews

        # If the chosen_location is not empty and the chosen_location is not in raw_locations
        # Means that the user chose a location with a new randomly generated review, which do not need to be summarised
        # Let the user to search and choose a location among raw_locations
        if chosen_location != "" and chosen_location not in raw_locations:
            print(f"No review found for {chosen_location} in the reviews.csv file.")
            # Remove duplicates in raw_locations
            locations = list(dict.fromkeys(raw_locations))
            chosen_location = self.search_location(locations)

        # If chosen_location is not empty string
        if chosen_location:
            # Generate the raw_reviews_with_locations dictionary
            raw_reviews_with_locations = p.assign_review_location(raw_reviews, raw_locations)
            # Get the filtered_raw_reviews_dict for the particular chosen_location
            filtered_raw_reviews_dict = raw_reviews_with_locations[chosen_location]
            # Compute the filtered_raw_reviews from the values of filtered_raw_reviews_dict
            filtered_raw_reviews = list(filtered_raw_reviews_dict.values())
            # Compute the filtered_raw_locations len(filtered_reviews) number of chosen_location
            filtered_raw_locations = [chosen_location] * len(filtered_raw_reviews)
        # Else, which the chosen_location is empty
        else:
            # Let filtered_raw_reviews and filtered_raw_locations remains unchanged from raw_reviews and raw_locations
            filtered_raw_reviews = raw_reviews
            filtered_raw_locations = raw_locations

        # Prompt user to input an integer regarding the number of reviews to be summarised
        num = self.prompt_int_input("How many reviews do you wish to summarise? ", (1, len(filtered_raw_reviews)))

        # Prompt user to input an integer regarding the number of sentences to be included in the summary
        n = self.prompt_int_input("How many sentences do you wish to include in the review summary? ", (1, 3))

        # Prompt user to input some selected_words
        print("Please input some selected words (in one line) to be prioritised when generating review summary.")
        input_str = input()
        # Remove special characters from the input_str, convert it to lowercase, and split the string to get selected_words_lst
        selected_words_lst = p.remove_special_characters(input_str).lower().split()
        # Remove duplicates in the list
        selected_words_lst = list(dict.fromkeys(selected_words_lst))

        # Let user to input word weight for every selected word and store the weight in the selected_words dictionary
        print("Please enter word weight for each selected word.")
        selected_words = {}
        for word in selected_words_lst:
            weight = self.prompt_int_input(f"{word}: ", (1, 5))
            selected_words[word] = weight

        # Set the words_to_ignore to the english stopwords list from nltk library
        words_to_ignore = list(stopwords.words('english'))
        # Prompt user to input some words_to_ignore
        print("Please input some words to ignore (in one line) to be trivialised when generating review summary.")
        input_str = input()
        # Remove special characters from the input_str, convert it to lowercase, and split the string to get a list of words
        words = p.remove_special_characters(input_str).lower().split()
        # Remove duplicates in the list
        words = list(dict.fromkeys(words))
        # Extend the list to words_to_ignore
        words_to_ignore.extend(words)

        print(f"Generating {num} longest review summaries based on instructions before...")
        # Zip the filtered_raw_reviews and filtered_raw_locations together
        z = zip(filtered_raw_reviews, filtered_raw_locations)
        # Sort the zipped iterable z by the length of filtered_raw_reviews, in reversed form
        z = sorted(z, key=lambda x: len(x[0]), reverse=True)
        # Unzip the iterable z
        filtered_raw_reviews, filtered_raw_locations = zip(*z)
        # Slice both list to the first num elements to get the final_reviews and final_locations
        final_reviews = filtered_raw_reviews[:num]
        final_locations = filtered_raw_locations[:num]

        # Create ReviewSummariser instance
        rs = ReviewSummariser()
        # Loop through every index and review in final_reviews
        for i, review in enumerate(final_reviews):
            # Compute the current location using index i
            location = final_locations[i]
            # Generate a summary for the review
            summary = rs.generate_summary(review, n, selected_words, words_to_ignore)
            # Print out the location and review summary
            print(f"{i+1}. {location}: {summary}")

    def sentiment_analyser(self, reviews: list, locations: list) -> None:
        """
        A function to let the user analyse reviews with SentimentAnalyser class.
        Let the user to choose between various ways (by pie chart, by scatter plot or both) to visualise compounds, sentiments, and locations.

        Arguments:
            - reviews: A list of reviews which can be overall reviews (reviews from all country) or reviews by country.
            - locations: A list of locations which corresponds to the review location for every review in reviews.

        Returns:
            - None.
        """
        # Create a SentimentAnalyser instance
        sa = SentimentAnalyser()
        # Generate compounds and reviews_with_locations_sentiments
        compounds, reviews_with_locations_sentiments = sa.insert_customer_sentiment(reviews, locations)
        # Create an empty list to store every sentiment_category in the reviews_with_locations_sentiments nested dictionary
        sentiment_categories = []
        # Loop len(locations) times
        for index in range(len(locations)):
            # Compute the current location
            location = locations[index]
            # Compute the sentiment_category
            sentiment_category = reviews_with_locations_sentiments[location][index][1]
            # Append the sentiment_category to the sentiment_categories list
            sentiment_categories.append(sentiment_category)
        
        # Prompt user to choose between various choices in choices_1 to visualise the sentiments, compounds and locations data
        print("\n\nHow do you want to visualise the corresponding data?")
        choices_1 = ["Generate a pie chart", "Generate a scatter plot", "Generate both pie chart and scatter plot", "Negative Review Extractor"]
        choice_1 = self.prompt_int_choice(choices_1)
        # If choice_1 is "Generate a pie chart" or "Generate both pie chart and scatter plot"
        if choice_1 in [0, 2]:
            # Ask user whether they want to sort the arragement of the element in the pie chart
            print("\n\nGenerating pie chart...\nDo you want to sort the arrangement of the pie chart element?")
            choices_2 = ["Yes", "No"]
            choice_2 = self.prompt_int_choice(choices_2)
            # If the choice is "Yes"
            if choice_2 == 0:
                # Invoke the generate_pie_chart function with sort=True
                generate_pie_chart(compounds, locations, sentiment_categories, True)
            # Else, which the choice is "No"
            else:
                # Invoke the generate_pie_chart function with default sort=False
                generate_pie_chart(compounds, locations, sentiment_categories)
            time.sleep(2)
            print("Generated a pie chart!")
            

        # If choice_1 is "Generate a scatter plot" or "Generate both pie chart and scatter plot"
        if choice_1 in [1, 2]:
            print("\n\nGenerating a scatter plot...")
            # Invoke the generate_scatter_chart function
            generate_scatter_chart(compounds, locations, sentiment_categories)
            time.sleep(2)
            print("Generated a scatter plot!")
        
        # If choice_1 is "Negative Review Extractor"
        if choice_1 == 3:
            # A list to store negatvie review is created
            negative_review_list = []
            # Loop through all sentiment categories
            for index in range(len(sentiment_categories)):
                # If it is negative review which in sentiment_categories is 0, append the review to the negative_review_list
                if sentiment_categories[index] == 0:
                    negative_review_list.append(reviews[index])
            # If the length of negative_review_list is not equal to 0, which means there is negative review
            if len(negative_review_list) != 0:        
                print("\nNegative review :")
                # Loop every negative review in negative_review_list and print it
                for num, review in enumerate(negative_review_list):
                    print(f"{num+1}. {review}")
            # Else, the length of negative_review_list is equal to 0, which means there is no negative review 
            else:
                print("\nNo negative review found.")

    def home(self) -> None:
        """
        A start function to let the user choose the field they want the analyse, between "View Franchise's Details", 
        "Analyse Reviews" and "Generate New Reviews". The function will execute repeatedly until the user chose to "Exit" the program.

        Arguments:
            - None.
        
        Returns:
            - None.
        """
        # Print following message
        print("Welcome to A Slice Of Py's Analysis System !!")
        while True:
            # Prompt user to choose between various choices
            print("\n\nWhich field do you want to analyse?")
            choices = ["View franchise's details", "Analyse reviews", "Generate new reviews", "Exit"]
            choice = self.prompt_int_choice(choices)
            # Invoke corresponding functions with respective choices
            if choice == 0:
                self.view_franchise_details()
            elif choice == 1:
                self.analyse_reviews()
            elif choice == 2:
                self.generate_new_reviews()
            # If choice is "Exit", break the while loop to end the program
            elif choice == 3:
                print("\n\nThank you for analysing!")
                break

if __name__ == "__main__":
    # Create a Main instance
    main = Main()
    # Execute the review analysis system by invoking the home function
    main.home()


"""
Example:
    Location: United Kingdom
    Reviews: 11 raw reviews

    Using the Feature Extractor method, by extracting 15 common words, from the bar chart/table generated, the word "food" has the highest count which is 3.
    Using the Review Summariser method, it can easily summarise the reviews with selected words and words to ignore and list the summaries down in the console.
    Using the Sentiment Analyser method, by generating scatter plot, there are 2 negative reviews and only 1 positive reviews given to the Franchise in United Kingdom and 8 reviews are neutral.

    To resolve customer's negative reviews, first go for [2] Analyse reviews on the main page of the system.
    Next, go for [2] By country and just search for the particular country. In this example we are searching United Kingdom.
    After that, go for [3] Sentiment Analyser and follow by [4] Negative Review Extractor to extract all negative reviews on franchise in the particular country.
    In this example, there is 2 negative reviews on franchise in United Kingdom.

    First negative review : Frozen pucks of disgust with some of the worst people behind the register.
    Suggestion : Give all the staff a training to ensure them having a great smile on face and give a friendly serving to customers.

    Second negative review : Hard to judge whether these sides were good because we were grossed out by the melted styrofoam and didn't want to eat it for fear of getting sick.
    Suggestion : Avoid using styrofoam container.
"""
