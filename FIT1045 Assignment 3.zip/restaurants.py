from datetime import datetime

class Menu:
    """
    Represents a menu.
    """

    def __init__(self) -> None:
        """
        Initialises a menu.
        """
        self.dishes = {}
        self.drinks = {}

    def get_dishes(self) -> dict:
        """
        Get the dishes instance variable.
        """
        return self.dishes

    def get_drinks(self) -> dict:
        """
        Get the drinks instance variable.
        """
        return self.drinks

    def set_dishes(self, dishes: list, price: list) -> None:
        """
        Set the dishes instance variable.
        """
        self.dishes = {dishes[i]: price[i] for i in range(len(dishes))}
            
    def set_drinks(self, drinks: list, price: list) -> None:
        """
        Set the drinks instance variable.
        """
        self.drinks = {drinks[i]: price[i] for i in range(len(drinks))}

    def display_menu(self, currency_symbol: str = "RM") -> None:
        """
        Displays every item in the menu.
        The currency_symbol is set to "RM" by default.
        """
        # Find the greatest length among all name of dishes and drinks
        food_len = max([len(x) for x in list(self.get_dishes().keys()) + list(self.get_drinks().keys())]) + 1
        # Find the greatest length among all price of dishes and drinks
        price_len = max([len(x) for x in list(self.get_dishes().values()) + list(self.get_drinks().values())]) + 1

        # Print dishes and its prices in the desire format
        print(f"\nDishes\n{'-' * (food_len + price_len + len(currency_symbol))}")
        for k, v in self.get_dishes().items():
            print("{1:<{0}}{2}{4:>{3}}".format(food_len, k.title(), currency_symbol, price_len, v))
        
        # Print drinks and its price in the desire format
        print(f"\nDrinks\n{'-' * (food_len + price_len + len(currency_symbol))}")
        for k, v in self.get_drinks().items():
            print("{1:<{0}}{2}{4:>{3}}".format(food_len, k.title(), currency_symbol, price_len, v))

class Restaurant:
    
    def __init__(self, menu: Menu) -> None:
        """
        Initialises a restaurant with the given data.
        """
        # Initialise instance variables with required values
        self.restaurant_name = "A Slice of Py"
        self.opening_time = "08:00"
        self.closing_time = "22:00"
        self.net_worth = 0.0
        self.number_of_staff = 0
        self.occupancy = 0
        self.menu = menu

    def get_net_worth(self) -> float:
        """
        Gets the earnings of a particular restaurant.

        Returns :
            - Float representing the net worth of the object.
        """
        return self.net_worth

    def set_restaurant_name(self, restaurant_name: str) -> None:
        """
        Sets the name of a particular restaurant.
        """
        self.restaurant_name = restaurant_name

    def set_restaurant_hours(self, opening_time: str, closing_time: str) -> None:
        """
        Sets the opening and closing times of a particular restaurant.
        """
        self.opening_time, self.closing_time = opening_time, closing_time

    def set_number_of_staff(self, number_of_staff: int) -> None:
        """
        Set the number of staff in a particular restaurant.
        """
        self.number_of_staff = number_of_staff
   
    def set_net_worth(self, net_worth: float) -> None:
        """
        Set the net worth of a particular restaurant.
        """
        self.net_worth = net_worth

    def set_occupancy(self, occupancy: int) -> None:
        """
        Increases the seating occupancy of a particular restaurant.
        """
        self.occupancy += occupancy

    def display_details(self) -> None:
        """
        Displays the restaurant's name, operating hours, and menu.
        The restaurant's operating hours needs to be converted from a 24-hour clock system to a 12-hour clock system
        (e.g. 17:00 to 05:00 PM).
        """
        # Create datetime object for opening_time and closing_time
        opening_time_obj = datetime.strptime(self.opening_time, '%H:%M')
        closing_time_obj = datetime.strptime(self.closing_time, '%H:%M')

        # Print following details and use datetime methods to convert the time to AM/PM format
        print(f"Welcome to {self.restaurant_name}!")
        print(f"Operating Hours: {opening_time_obj.strftime('%I:%M %p')} to {closing_time_obj.strftime('%I:%M %p')}")
        # Invoke Menu class display_menu() function to print menu details
        self.menu.display_menu()

    def __str__(self) -> None:
        """
        Returning the restaurant_name, occupancy, number_of_staff, and net_worth when a Restaurant object is printed.
        """
        return f"{self.restaurant_name} (Occupancy: {self.occupancy}, Staff: {self.number_of_staff}, Net Worth: RM{self.get_net_worth()})"
