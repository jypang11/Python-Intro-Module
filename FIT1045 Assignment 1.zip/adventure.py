#Team Name: Meme 
#Team Members: Tan Wei Ming, Brandon Pang, Chew Chee Lel, Christopher Ting
#Last Edit Date: 11/11/2022(code finished) 19/11/2022(2nd edition)

import random
import time

possible_scenarios = {
    "negative_scenarios": [
    "Oh no! There's deadly mosquitos!", 
    "Oh no! The murky water is too high!",
    "Uh oh. You got lost!",
    "GG.com", 
    "Hou Yam Gong", 
    "完了完了完了，芭比Q了"], 
    
    "positive_scenarios": [   
    "Woohoo, you found a shortcut!",
    "Nailed it, you solved a riddle posed by a troll!",
    "Oh my God... you found gold!",
    "Wah, you so geng!", 
    "666, you got a bonus!", 
    "牛逼克拉斯"]}

dice_symbol = ["𝟘", "𝟏", "𝟚", "𝟛", "𝟜", "𝟝", "𝟞", "𝟟", "𝟠", "𝟡", "𝟏𝟘", "𝟏𝟏", 
"𝟏𝟚", "𝟏𝟛", "𝟏𝟜", "𝟏𝟝", "𝟏𝟞", "𝟏𝟟", "𝟏𝟠", "𝟏𝟡", "𝟐𝟘"]

def get_number_of_players() -> int:
    """
    Prompt to get input for number of player. 

    Arguments:
        - None.

    Returns:
        - number_of_players: integer of number of players in this game.
    """
    # set number_of_players to None
    number_of_players = None
    # keep looping while number_of_players is None, this happens when an invalid statement is inputted from the user
    while number_of_players == None:
        # the try-except block helps us to prevent error when there is an invalid statement inputted from the user
        try:
            # get number of players from user
            number_of_players = int(input("Please enter total number of players: "))
            # keep prompting user to input if the number_of_players is invalid (number of players must greater than 0)
            while number_of_players < 1:
                print("Sorry! You must enter 1 or more!\n")
                number_of_players = int(input("Please enter total number of players: "))
        except:
            # print the statement below if an invalid statement is inputted
            print("You entered an invalid statement, please retry.\n")
            # set number_of_players to None to go for a next loop
            number_of_players = None

    return number_of_players

def get_player_names(number_of_players: int) -> list:
    """
    Prompt each player to input their name. 
    The number of iteration needed is based on the input argument, number_of_players.

    Arguments:
        - number_of_players: Integer argument from get_number_of_players function.
        Representing number of players in game.

    Returns:
        - player_names: List of player names where the first letter of each name is capitalised.
    """
    # create a list of empty strings to adequate size
    player_names = [""] * number_of_players

    # iterate number_of_players times to prompt user to input names and store them into player_names
    for player in range(number_of_players):
        # prompt input, clear leading and trailing space in name, capitalize the name
        name = input("Please enter the name of player " + str(player + 1) + ": ").strip().capitalize()

        # repeat to prompt user input if the name entered is the same as other player
        while name in player_names:
            name = input(name + " is already taken, pick another name for player " + str(player + 1) + ": ").strip().capitalize()
            
        player_names[player] = name

    return player_names

def get_print_statement(player_names: list) -> str:
    """
    Create an ouput string with "Adventure will now begin with " combine with the player name in the player_names list. 

    Arguments:
        - player_names: String argument in player_name list from get_player_names function.
        Representing the player name in the game.

    Returns:
        - output: String that includes "Adventure will now begin with " combine with player_names.
    """
    # create a sample output string
    output = "Adventure will now begin with "

    # the index that will be used in the following for loop to check whether to use ", ", " and " or "." after player's name
    index = len(player_names)
    
    # repeat adding every player_name in player_names to the output string
    for player_name in player_names:
        if index > 2:       # When index > 2, there are more than 2 player_name that haven't been added to the output string, so we use ", "
            output += player_name + ", "
        elif index == 2:    # When index = 2, there are only 2 player_name haven't been added, so we use " and "
            output += player_name + " and "
        else:               # This else statement can possibly only have index = 1, which means there is 1 last player_name, so we use "."
            output += player_name + "."

        index -= 1          # update the value of index to match the number of remaining player_name that haven't been added to the output string

    return output

def get_dice_variation() -> str:
    """
    This is a function to choose dice randomly.

    Arguments:
        - None.

    Returns:
        - dice_variation: String which is randomly picked from the four choices which are D4, D8, D12, D16.
    """
    # randomly choose one of the four dices and store the type of the dice as a string into dice_variation
    dice_variation = random.choice(["D4", "D8", "D12", "D20"])

    return dice_variation

def get_dice_value(dice_variation: str) -> int:
    """
    This is a function to choose dice_value randomly from dice_variation picked in get_dice_variation function.

    Arguments:
        - dice_variation: String argument from get_dice_variation function.
        Representing the dice type to be thrown.

    Returns:
        - dice_value: Integer which is randomly picked from 1 to the value of the dice_variation.
    """
    # randomly choose the value between 1 to the maximum value of the dice(depends on the dice_variation) and store it into dice_value
    # the int(dice_variation[1:]) first extract the dice number from dice_variation then convert it to int type to get the maximum value of the dice
    dice_value = random.randint(1, int(dice_variation[1:]))
    
    return dice_value

def check_overshot(current_score: int, dice_value: int) -> tuple:
    """
    This is a function to check if there is overshootthe score after throwing a dice if over the winning score.

    Arguments:
        - current_score: Integer argument
        Representing the current_score to check overshoots after getting dice_value.

        - dice_value : Integer argument from get_dice_value function.
        Representing the dice value to be added to current score to check overshoots. 

    Returns:
        - overshot_checking_tuple: Tuple which form by a boolean overshot, 
        an integer new_score obtained by adding current_score with dice_value and 
        an integer difference obtained by substaction of winning_score with new_score which 
        new_score is obtained by addition of current_score and dice_value or
        just equal to current_score if there is an overshot.
    """
    # create a bool variable overshot and assume overshot = False at first
    overshot = False

    # winning_score is 50 based on the task
    winning_score = 50

    # check if the sum of current_score and dice_value greater than the winning_score
    if (current_score + dice_value) > winning_score:
        # if the sum is greater than the winning_score, new_score remains as current_score, and update overshot to True
        new_score = current_score
        overshot = True
    else:
        # if the sum is smaller than or equal to winning_score, update the new_score with the sum and overshot remains unchanged
        new_score = current_score + dice_value
    
    # calculate the difference between the winning_score and the new_score
    difference = winning_score - new_score

    # create a tuple that store the value: overshot, new_score and difference
    overshot_checking_tuple = (overshot, new_score, difference)

    return overshot_checking_tuple

def determine_scenario(scenario_type: str, possible_scenarios: dict) -> str:
    """
    This is a function to choose scenario dialog from possible_scenarios dictionary randomly.

    Arguments:
        - scenario_type: String argument from score_after_occurrences function.
        Representing the type of scenario in order to choose the scenario statement in that particular scenario.

        - possible_scenarios: Global dictionary.

    Returns:
        - scenario: String which is picked randomly from dictionary possible_scenarios.
    """
    # check the scenario_type given is positive or negative and randomly choose the scenario dialog from possible_scenarios
    if scenario_type == "positive":
        # if the scenario_type is "positive", the scenario dialog should be chosen from the positive_scenarios in possible_scenarios
        # create an index to store the value of random number between 0 to the length of positive_scenarios in possible_scenarios
        index = random.randrange(0, len(possible_scenarios["positive_scenarios"]))
        # use that index to choose a dialog from the possible_scenarios
        scenario = possible_scenarios["positive_scenarios"][index].upper()
    elif scenario_type == "negative":
        # if the scenario_type is "negative", the scenario dialog should be chosen from the negative_scenarios in possible_scenarios
        # create an index to store the value of random number between 0 to the length of negative_scenarios in possible_scenarios
        index = random.randrange(0, len(possible_scenarios["negative_scenarios"]))
        # use that index to choose a dialog from the possible_scenarios
        scenario = possible_scenarios["negative_scenarios"][index].upper()

    return scenario

def scenario_statement(previous_score: int, current_score: int, player_name: str, scenario_type: str) -> str:
    """
    This is a function to get the scenario_statement.

    Arguments:
        - previous_score: Integer argument.
        Representing score before occurrence.

        - current_score: Integer arguments.
        Representing score after occurrence.
        
        - player_name: String argument from player_names list.
        Representing the player name in the game.

        - scenario_type: String argument from score_after_occurrences function.
        Representing the type of scenario in order to choose the scenario statement in that particular scenario.
   
    Returns:
        - dice_variation: String which randomly picked from the four choices which are D4, D8, D12, D16.
    """
    # create an output_statement to store the output string
    output_statement = player_name + " got "

    # check if the scenario_type is negative or positive to concatenate different kind of strings
    if scenario_type == "negative":
        output_statement += "unlucky. Score decreased from "
    elif scenario_type == "positive":
        output_statement += "lucky. Score increased from "

    # concatenate the output_statement with the previous_score and current_score
    output_statement += str(previous_score) + " to " + str(current_score) + "!"

    return output_statement

def generate_pass_chance() -> bool:
    """
    This is a function to generate pass chance according to possibility.

    Arguments:
        - None.
    
    Returns:
        - pass_chance: Boolean which is True or False.
    """
    # generate a probablity between 0 and 1 using random.random function
    prob = random.random()
    
    # check if the probablity is greater or lesser than 0.20
    # if it is greater, then pass_chance will be False, else pass_chance will be True
    # this means there are 80% chance of getting False and 20% chance of getting True
    if prob >= 0.20:
        pass_chance = False
    else:
        pass_chance = True

    return pass_chance

def generate_occurrences() -> dict:
    """
    This is a function to generate positive_occurrences and negative_occurrences dictionaries randomly.
    10 pairs of key and value for each occurrence dictionary is generated randomly with randint function.

    Arguments:
        - None.
    
    Returns:
        - positive_occurrences, negative_occurrences: Dictionaries.
    """
    # create variable max_score and min_score to store the value of maximum and minimum score
    max_score = 50
    min_score = 0

    # create an empty dictionary to store 10 possible positive occurrences
    positive_occurrences = {}

    # keep looping to add positive occurrence while the length of the positive_occurrences haven't reach 10
    while len(positive_occurrences) < 10:
        # the targeted_score should be a random number between 1 to 49
        targeted_score = random.randint(1, 49)
        # create a score_to_be_added to store a random number between 1 to 10
        score_to_be_added = random.randint(1, 10)

        # check if the sum of targeted_score and score_to_be_added exceeds the value of max_score
        if (targeted_score + score_to_be_added) <= max_score:
            # if it does not, store the sum into score_after_addition
            score_after_addition = targeted_score + score_to_be_added
        else:
            # if it exceeds, continue to a next loop to get a new positive occurrence
            continue
            total_infected = 0
        # add the pair of targeted_score and score_after_addition into the dictionary positive_occurrences
        positive_occurrences[targeted_score] = score_after_addition
    
    # create an empty dictionary to store 10 possible negative occurrences
    negative_occurrences = {}

    # keep looping to add negative occurrence while the length of the positive_occurrences haven't reach 10
    while len(negative_occurrences) < 10:
        # the targeted_score should be a random number between 1 to 49
        targeted_score = random.randint(1, 49)
        # the loop below checks if the targeted_score is already exists in positive_occurrences, if so, keep looping to generate a new targeted_score
        while targeted_score in positive_occurrences:
            targeted_score = random.randint(1, 49)
        # create a score_to_be_subtracted to store a random number between 1 to 10
        score_to_be_subtracted = random.randint(1, 10)

        # check if the subtraction of targeted_score and score_to_be_subtracted smaller than the value of min_score
        if (targeted_score - score_to_be_subtracted) >= min_score:
            # if it does not, store the result after subtraction into score_after_subtraction
            score_after_subtraction = targeted_score - score_to_be_subtracted
        else:
            # if it does, continue to a next loop to get a new negative occurrence
            continue

        # add the pair of targeted_score and score_after_subtraction into the dictionary positive_occurrences
        negative_occurrences[targeted_score] = score_after_subtraction

    return positive_occurrences, negative_occurrences

def score_after_occurrences(current_score: int, positive_occurrences: dict, negative_occurrences: dict) -> tuple:
    """
    This is a function compute the score after occurrences when a occurrence occured.

    Arguments:
        - current_score: Integer argument.
        Representing the score to be check in the occurrences dictionary.

        - positive_occurrences: positive_occurrences dictionary from generate_occurrences function.
        The key representing the score in which when reached by the player 
        to get the value of key as new_score after addition.

        - negative_occurrences: negative_occurrences dictionary from generate_occurrences function.
        The key representing the score in which when reached by the player 
        to get the value of key as new score after substaction.
    
    Returns:
        - occurrence_tuple: A tuple which consist of occurrence (a string of "positive" or "negative")
        and new_score (an integer of score after occurrence).
    """
    # check if the current_score matches any key in positive_occurrences or negative_occurrences
    # then store the occurence occured and compute the new_score using the dictionaries
    if current_score in positive_occurrences:
        occurrence = "positive"
        new_score = positive_occurrences[current_score]
    elif current_score in negative_occurrences:
        occurrence = "negative"
        new_score = negative_occurrences[current_score]
    else:
        occurrence = "neither"
        new_score = current_score
    
    # create a tuple to store the occurence occured and new_score
    occurrence_tuple = (occurrence, new_score)

    return occurrence_tuple

def visualise_game(player_names: list, player_scores: list, current_player_index: int) -> None:
    """
    This is a function to print the scoreboard which consist of player_names with their score 
    and whose turn to play with the first letter of name at the last place of his score
    and the winning_score with its number of asterisks for easy comparision.

    Arguments:
        - player_names: List argument from get_player_names function.
        Representing the player name in the game.

        - player_scores: List argument.
        Storing score for each player.

        - current_player_index: Integer argument.
        Representing the index in player_name list in order to know who is playing currently.
    
    Returns:
        - None.
    """
    # create a variable winning_score to store the string "Winning score"
    winning_score = "Winning score"
    # create a score_index to keep track of which player we are printing in the following loop
    score_index = 0

    # a for loop to check which player_name or winning_score has the longest length and store the length into max_length
    for name in player_names:
        max_length = max(len(name), len(winning_score))+1
    
    # a for loop to compute every player's name and score and print them to the terminal
    for name in player_names:
        # this while loop will keep concatenating with " " when the length of the name of the player is lesser than the max_length
        while len(name) < max_length:
            name += " "
        # check if we are printing the current player, the first letter of their name will be printed in place of the last asterisk
        if current_player_index == score_index:
            player_output = name + "*" * (player_scores[score_index] - 1) + name[0]
        else:
            player_output = name + "*" * player_scores[score_index]
        
        # print the player_output
        print(player_output)
        # update the value of score_index
        score_index += 1
    
    # concatenate the winning_score with " " if the length of winning_score is lesser than max_length
    while len(winning_score) < max_length:
        winning_score += " " 
    print(winning_score + "*" * 50)

def play_turns(player_name: str, current_score: int, dice_value: int, possible_scenarios: dict) -> int:
    """
    This is a function to run a play of turn for the game.

    Arguments:
        - player_name: String argument from get_player_names function.
        Representing the player name in the game.

        - current_score: Integer argument.
        Representing the score of that particular player.

        - dice_value: Integer from get_dice_value function.
        Representing the value needed to add after throwing a dice.

        - possible_scenarios: Global dictionary.
    
    Returns:
        - final_score: Integer of score after a play turn.
    """
    # check if the player have overshot and store the result in variable overshot
    overshot = check_overshot(current_score, dice_value)[0]
    # update the score of the player to second_score
    second_score = check_overshot(current_score, dice_value)[1]
    # store the difference between the player score and winning score into variable difference
    difference = check_overshot(current_score, dice_value)[2]

    # check if there is overshot happened and prompt two different kind of strings
    if overshot == False:
        print(player_name + " progressed from " + str(current_score) + " to " + str(second_score) + ".\n")
    else:
        # if there is overshot happened, print out the statement and straightly return the current_score
        # (PS: in this situation, the second_score and current_score are the same)
        print(player_name + " overshoots! Player needs to roll " + str(difference) + " to win this game. Keep trying.\n")
        return current_score

    # compute positive_occurrences and negative_occurrences using the generate_occurrences function
    # compute scenario_type and update the score to third_score using the score_after_occurrences function
    positive_occurrences, negative_occurrences = generate_occurrences()
    scenario_type = score_after_occurrences(second_score, positive_occurrences, negative_occurrences)[0]
    third_score = score_after_occurrences(second_score, positive_occurrences, negative_occurrences)[1]

    # generate a pass chance using generate_pass_chance function and store the boolean result into chance
    chance = generate_pass_chance()

    # print different statement based on the situations
    if scenario_type == "positive" or (scenario_type == "negative" and chance == False):
        # if it is a positive scenario; or if the scenario is negative and there is no pass chance, print statement below
        print(determine_scenario(scenario_type, possible_scenarios) + "\n")
        print(scenario_statement(second_score, third_score, player_name, scenario_type) + "\n")
        # in this situation, the final_score will be the same as third_score(which is the score after occurrence)
        final_score = third_score
    elif scenario_type == "negative" and chance == True:
        # if it is a negative scenario and the player get a pass chance, print the statement below
        print(determine_scenario(scenario_type, possible_scenarios) + "\n")
        print(player_name + " successfully overcome the obstacle!\n")
        print("Score will remain at " + str(second_score) + ".\n")
        # in this situation, since the player get the pass chance, the final_score will be the same as second_score(which is the score before occurrence)
        final_score = second_score
    else:   
        # the scenario_type is "neither", therefore the final_score should remain unchanged from second_score
        # (PS: in this situation, the second_score and third_score are the same)
        final_score = second_score

    return final_score

def welcome_msg() -> None:
    """
    String welcome message for the players at the start of Adventure Land.
    
    Arguments:
        - None

    Returns:
        - None
    """
    
    msg = """
    ------------------------------

    Welcome to AdventureLand!
    
    Rules:
    1. Players begin with a score of 0.
    2. Players will receive a random variation of dice at each turn.
    3. Each player will take turns to do one dice roll until one player reaches a score of 50. 
    4. If a player rolls too high and overshoots, then the player does not move for that round. 
    5. Players will face a randomised set of positive and negative scenarios.
    6. Every player will have a probablity of 0.2 to pass any obstacles faced.
    
    ------------------------------
    

    """
    print(msg)


def colour_choose(player_names: list) -> list:
    """
    A function to prompt user to choose the colour for the game.
    
    Arguments:
        - player_names: List argument.
        Representing the player name to print in the prompt.

    Returns:
        - colour_chosen: List argument.
        Representing the colour chosen by the player.
    """
    # empty list to store colour code choose by user
    colour_chosen = []
    # variable initialize
    index = 32
    colour_code = 0
    # colour list provided to choose
    colour_list = ["1.green","2.yellow","3.blue","4.magenta","5.cyan"]

    # the for loop below is used to print every colour that can be chosen
    for colour in colour_list:
        print(f"\u001b[{index}m{colour} ", end="")
        print(f"\u001b[0m", end="")
        index += 1

    # this for loop will keeping looping until every player has chosen their desire colour for the game
    for i in range (len(player_names)):
        # set colour to None
        colour = None
        # keep looping while colour is None, this happens when an invalid statement is inputted from the user
        while colour == None:
            # the try-except block helps us to prevent error when there is an invalid statement inputted from the user
            try:
                # prompt statement and get colour number from user
                colour = int(input(f"\n{player_names[i]}, please choose a colour and type the number: "))
                # keep prompting user to input if the colour number is invalid
                while colour < 1 or colour > 5:
                    print("Please enter the correct number for the colour.")
                    colour = int(input(f"\n{player_names[i]}, please choose a colour and type the number: "))
                # update the colour_code according to the colour chosen by adding colour number with 31
                colour_code = colour + 31
                # store the colour_code in the list colour_chosen
                colour_chosen.append(colour_code)
            except:
                # print the statement below if an invalid statement is inputted
                print("You entered an invalid statement, please retry.")
                # set number_of_players to None to go for a next loop
                colour = None

    return colour_chosen

def start():
    """
    This is a function to run a game.

    Arguments:
        - None.
    
    Returns:
        - None.
    """
    # print the welcome_msg
    welcome_msg()
    # sleep for one second
    time.sleep(1)

    # generate numbers_of_player using get_number_of_players
    number_of_players = get_number_of_players()
    # prompt user to input player names and store them in a list 
    player_names = get_player_names(number_of_players)
    # prompt user to choose colour
    colour_chosen = colour_choose(player_names)
    # sleep for one second
    time.sleep(1)

    # print out all players that are playing the games
    print("\n" + get_print_statement(player_names))

    # set the winning_score to 50
    winning_score = 50
    # create a list to store all scores of the players
    player_scores = [0] * number_of_players
    # create an index to keep track how many round has been played
    round_index = 1
    # create a list of dialogs
    dialog = ["Go.", "Please proceed.", "Lets win this.", "Your turn."]

    # keep looping when there is none of the player has a score of 50
    while winning_score not in player_scores:
        # create an index to keep track which player is playing
        current_player_index = 0
        # print out the current round
        print("\n------------ROUND " + str(round_index) + "------------\n")
        # update round_index for next use
        round_index += 1

        # keep looping until every player played the game for each round
        for player_name in player_names:
            # print colour selected by user
            print(f"\u001b[{colour_chosen[current_player_index]}m", end="")
            # prompt this statement and get input from the user 
            player_input = input(player_name + ": " + random.choice(dialog) + " Hit enter to roll dice 🎲: ")

            # keep prompting user when they entered statement other than enter
            while player_input != "":
                print("You entered an invalid statement, please retry.")
                player_input = input(player_name + ": " + random.choice(dialog) + " Hit enter to roll dice 🎲: ")
            
            # get dice variation using get_dice_variation function and print the corresponding statement
            dice_variation = get_dice_variation()
            print("\nRolling " + dice_variation + " dice 🎲...\n")
            time.sleep(1)

            # compute the dice value using get_dice_value function
            dice_value = get_dice_value(dice_variation)
            print(player_name + " adventuring....\n")
            # print out the dice value that the player got
            print(player_name + " get " + dice_symbol[dice_value] + "\n")

            # reset colour 
            print("\u001b[0m", end="")
            time.sleep(2)

            # print red colour text
            print(u"\u001b[31m", end="")
            # update the score of the current player by using the play_turns function
            player_scores[current_player_index] = play_turns(player_name, player_scores[current_player_index], dice_value, possible_scenarios)
            # visualise the game using visualise_game function
            visualise_game(player_names, player_scores, current_player_index)
            # end the red colour printing
            print(u"\u001b[0m\n\n")

            # break the while loop when the current player reached the score of 50
            if player_scores[current_player_index] == winning_score:
                # store the name of the current player to the variable winner
                winner = player_name
                break

            # update the current_player_index for next use
            current_player_index += 1

    # the dialogs below are just some ending statements and a cute rabbit :) to print out 
    ending_dialog = """
-----------------------------

Thats the end of Adventure Land!


{} won the game.


 (\__(\ 
 („• - •„)
┏∪∪━━━━━━━━━━━━━┓
 CONGRATULATIONS
 {:^15}
┗━━━━━━━━━━━━━━━━┛
    ↖(^▽^)↗

----------------------------
"""
    print(ending_dialog.format(winner, winner))

# execution of the game
if __name__ == "__main__":
    start()
