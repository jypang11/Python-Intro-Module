from player_move import LPlayer
from property import Property
import random
import math
 
class AIPlayer(LPlayer):
    """ AIPlayer Class for representing AI players in the pypoly board game. """

    # Constructor
    def __init__(self) -> None:
        """ 
        Constructor of class AIPlayer and super class inherited from class LPlayer. 
        Initialise instance variable. 
        """
        super().__init__()
        # Declare another instance variable to be used in ai_move
        self.invalid_move = None
        # Set the default name of AI players to "AI"
        self.set_name("AI")
    
    # Accessor (Getter)
    def get_invalid_move(self) -> tuple:
        """ 
        A method to get instance variable invalid move from the constructor of the object. 
            
        Arguments: 
            - self
        
        Returns: 
            - Instance variable invalid move of the object. 
        """
        return self.invalid_move
    
    # Mutator (setter)
    def set_invalid_move(self, invalid_move) -> None:
        """ 
        A method to set instance variable invalid move of the object. 
            
        Arguments: 
            - self
            - List of invalid move.
        
        Returns: 
            - None. 
        """
        self.invalid_move = invalid_move

    # Methods
    def recurring_colour(self) -> list[str]:
        """ 
        A method that finds the most frequently occurring colour group(s) among the properties owned by the AI player. 
            
        Arguments: 
            - self
        
        Returns: 
            - List of colour which the most frequently occurring colour group(s). 
        """
        # Create a empty list most_colour to represent the most frequently occurring colour group(s) among the AI player's properties
        most_colour = []
        # If the AI player does not has any property owned, extend the most_colour list with all colour_groups
        if len(self.get_properties_owned()) == 0:
            most_colour.extend(Property.COLOUR_GROUPS)
        # Else, which means that the Ai player has at least one property owned
        else:
            # Create a empty dictionary colour_count
            colour_count = {}
            # Loop through every colour in the COLOUR_GROUPS
            for colour in Property.COLOUR_GROUPS:
                # Using the colour as key, initialise 0 as value in the colour_count dictionary
                colour_count[colour] = 0
                # Loop through every property in the AI properties_owned list
                for property in self.get_properties_owned():
                    # If the property's colour_group is the same as the colour currently looping from the outer loop
                    if property.get_colour_group() == colour:
                        # Update the value of the colour in the colour_count dictionary
                        colour_count[colour] += 1
            # Loop through every keys in the colour_count dictionary
            for element in colour_count.keys():
                # If the value is equal to the max value amongst all the values in the dictionary
                if colour_count[element] == max(colour_count.values()):
                    # Append the most_colour list with the colour
                    most_colour.append(element)
        # Return the most_colour list
        return most_colour
        
    def ai_move(self, possible_moves: list[tuple], property_locations: dict) -> tuple:
        """ 
        A method that that determines the best move the AI player should make.  
            
        Arguments: 
            - self
            - List of tuples of possible moves
            - Dictionary of property location
        
        Returns: 
            - Tuple of the best move of the AI Player. 
        """
        # If the invalid_move is not equal to None
        # It means that the AI Player cannot revisit the same location in this round
        if self.get_invalid_move() != None:
            # Remove the invalid_move in the possible_moves list
            possible_moves.remove(self.get_invalid_move())
        # Set the invalid_move to the AI player's current position
        self.set_invalid_move(self.get_position())

        # Create to empty lists to represent first_priority_moves and second_priority_moves of the AI player
        first_priority_moves = []
        second_priority_moves = []
        # Loop through every moves in the possible_moves list
        for move in possible_moves:
            # Get the property instance by using move tuple as key in the property_locations dictionary
            property = property_locations[move]
            # If the property colour is in the recurring_colour list and the owner is Bank and the AI could afford purchasing the property
            if property.get_colour_group() in self.recurring_colour() and property.get_owner() == "Bank" and self.get_fund() > property.get_property_cost():
                # Append the move in the first_priority_moves list
                first_priority_moves.append(move)
            # Else if the property colour is in the recurring_colour list and the owner is AI itself and there are 0 hotels_built and AI could afford constructing a hotel on it
            elif property.get_colour_group() in self.recurring_colour() and property.get_owner() == self and property.get_hotels_built() == 0 and self.get_fund() > property.get_hotel_cost():
                # Append the move in the first_priority_moves list
                first_priority_moves.append(move)
            # Else if the property is "Reward"
            elif property.get_property_name() == "Reward":
                # Append the move in the second_priority_moves list
                second_priority_moves.append(move)
            # Else if the property owner is AI itself or the property owner is "Bank" but not "Penalty"
            # which means this is the property list which the AI does not need to pay rent or get penalty
            elif property.get_owner() == self or (property.get_owner() == "Bank" and property.get_property_name() != "Penalty"):
                # Append the move in the second_priority_moves list
                second_priority_moves.append(move)
        
        # If the first_priority_moves is not empty
        if len(first_priority_moves) != 0:
            # Randomly choose one move from the first_priority_moves list and return it
            return random.choice(first_priority_moves)
        # Else if the second_priority_moves is not empty
        elif len(second_priority_moves) != 0:
            # Randomly choose one move from the second_priority_moves list and return it
            return random.choice(second_priority_moves)
        # Else, which means first_priority_moves and second_priority_moves are both empty
        else:
            # Randomly choose one move from the possible_moves list and return it
            return random.choice(possible_moves)

    def buy_or_build(self, best_move: tuple, property_locations: dict) -> None:
        """ 
        A method that that determines whether the AI player should purchase a property, build a hotel on a previously purchased property, or make other decisions or calls. 
            
        Arguments: 
            - self
            - Tuple of best move
            - Dictionary of property location

        Returns: 
            - None. 
        """
        # Get the property instance by using best_move tuple as key in the property_locations dictionary
        property = property_locations[best_move]
        # If the property is owned by AI but the property is not in the recurring_colour list
        if property.get_owner() == self and property.get_colour_group() not in self.recurring_colour():
            # Sell the property to gain the fund back
            self.sell_property(property)
        # Check if demermine_action() returns True or False, if it's True
        # It means that AI could purchase the property or construct a hotel on it
        if self.determine_action(property_locations):
            # If the property owner is "Bank" and AI could afford purchasing it
            if property.get_owner() == "Bank" and self.get_fund() > property.get_property_cost():
                # Purchase the property
                self.purchase_property(property)
            # Else if the property owner is AI itself and AI could afford constructing a hotel on it
            elif property.get_owner() == self and self.get_fund() > property.get_hotel_cost():
                # Purchase a hotel
                self.purchase_hotel(property)
