import time
import math
import random

from property import Property
from property_generator import PropertyGenerator
from player import Player
from player_move import PerpendicularPlayer, DiagonalPlayer, LPlayer
from ai_player import AIPlayer

import property_csv_data_a as a
import property_csv_data_b as b

class PyPoly:
    # Class variable
    MOVE_TRAITS = ["Perpendicular", "Diagonal", "L"]

    # Constructor
    def __init__(self):
        """
        Constructor of the class PyPoly.
        Initialise instance variables.

        Arguments:
            - self

        Returns:
            - None.
        """    
        self.number_of_players = 0
        self.number_of_AI_players = 0
        self.number_of_regular_players = 0
        self.winning_condition = 0
        self.player_names = []
        self.properties = None
        self.property_locations = None
        # players, a list to store all Player instances
        self.players = []
        
    # Accessors (Getters)
    def get_number_of_players(self) -> int:
        """ 
        A method to get instance variable number_of_players of the object. 

        Arguments: 
            - self

        Returns: 
            - Integer of instance variable number_of_players of the object. 
        """
        return self.number_of_players

    def get_number_of_AI_players(self) -> int:
        """ 
        A method to get instance variable number_of_AI_players of the object. 

        Arguments: 
            - self

        Returns: 
            - Integer of instance variable number_of_AI_players of the object. 
        """
        return self.number_of_AI_players

    def get_number_of_regular_players(self) -> int:
        """ 
        A method to get instance variable number_of_regular_players of the object. 

        Arguments: 
            - self

        Returns: 
            - Integer of instance variable number_of_regular_players of the object. 
        """
        return self.number_of_regular_players

    def get_winning_condition(self) -> int:
        """ 
        A method to get instance variable winning_condition of the object. 

        Arguments: 
            - self

        Returns: 
            - Integer of instance variable winning_condition of the object. 
        """
        return self.winning_condition

    def get_player_names(self) -> list[str]:
        """ 
        A method to get instance variable player_names of the object. 

        Arguments: 
            - self

        Returns: 
            - List of string of instance variable player_names of the object. 
        """
        return self.player_names

    def get_properties(self) -> list[Property]:
        """ 
        A method to get instance variable properties of the object. 

        Arguments: 
            - self

        Returns: 
            - List of Object Property of instance variable properties of the object. 
        """
        return self.properties

    def get_property_location(self) -> dict:
        """ 
        A method to get instance variable property_locations of the object. 

        Arguments: 
            - self

        Returns: 
            - Dictionary of instance variable property_locations of the object. 
        """
        return self.property_locations

    def get_players(self) -> list[Player]:
        """ 
        A method to get instance variable players of the object. 

        Arguments: 
            - self

        Returns: 
            - List of Object Player of instance variable players of the object. 
        """
        return self.players
    
    # Mutators (Setters)
    def set_number_of_players(self, number_of_players: int) -> None:
        """ 
        A method to set instance variable number_of_players of the object. 

        Arguments:
            - self
            - Integer of number_of_players

        Returns: 
            - None. 
        """
        self.number_of_players = number_of_players

    def set_number_of_AI_players(self, number_of_AI_players) -> None:
        """ 
        A method to set instance variable number_of_AI_players of the object. 

        Arguments:
            - self
            - Integer of number_of_AI_players

        Returns: 
            - None. 
        """
        self.number_of_AI_players = number_of_AI_players

    def set_number_of_regular_players(self, number_of_regular_players) -> None:
        """ 
        A method to set instance variable number_of_regular_players of the object. 

        Arguments:
            - self
            - Integer of number_of_regular_players

        Returns: 
            - None. 
        """
        self.number_of_regular_players = number_of_regular_players

    def set_winning_condition(self, winning_condition: int) -> None:
        """ 
        A method to set instance variable winning_condition of the object. 

        Arguments:
            - self
            - Integer of winning_condition

        Returns: 
            - None. 
        """
        self.winning_condition = winning_condition

    def set_player_names(self, name: str) -> None:
        """ 
        A method to set instance variable player_names of the object. 

        Arguments:
            - self
            - String of name

        Returns: 
            - None. 
        """
        self.player_names.append(name)

    def set_properties(self, properties: list) -> None:
        """ 
        A method to set instance variable properties of the object. 

        Arguments:
            - self
            - List of properties

        Returns: 
            - None. 
        """
        self.properties = properties

    def set_property_location(self, property_locations: dict) -> None:
        """ 
        A method to set instance variable property_location of the object. 

        Arguments:
            - self
            - Dictionary of property_locations

        Returns: 
            - None. 
        """
        self.property_locations = property_locations

    def set_players(self, player: Player) -> None:
        """ 
        A method to set instance variable players of the object. 

        Arguments:
            - self
            - Object player

        Returns: 
            - None. 
        """
        self.players.append(player)

    # Methods
    def print_welcome_messages(self) -> None:
        """
        A method to print welcome message.

        Arguments:
            - self
        
        Returns:
            - None.
        """
        print("Welcome to 💰 PyPoly 💰\n\n")

    def prompt_number_of_players(self) -> None:
        """
        A method to prompt user for number_of_AI_players in the game.

        Arguments:
            - self
        
        Returns:
            - None.
        """
        while True:
            # This try-except block is to prevent error while getting invalid input from user
            try:
                # Prompt user to input number_of_players
                number_of_players = int(input("How many players do you want? "))
                # Keep prompting user to input while the number_of_players is not between 2 and 6
                while not (2 <= number_of_players <= 6):
                    print("Sorry! The number of players must between 2 to 6.")
                    number_of_players = int(input("How many players do you want? "))
                # Break the while loop when an appropriate statement inputted by user
                break
            # Print corresponding message while getting invalid statement or KeyboardInterrupt from user input
            except ValueError:
                print("You entered an invalid statement, please retry.")
            except KeyboardInterrupt:
                print("\nWhere do you think you are going?")
        print("\n")
        # Set the number_of_players to the instance variable number_of_players
        self.set_number_of_players(number_of_players)
    
    def prompt_play_with_AI(self) -> None:
        """
        A method to prompt user for number_of_AI_players in the game.

        Arguments:
            - self
        
        Returns:
            - None.
        """
        while True:
            # This try-except block is to prevent error while getting invalid input from user
            try:
                # Prompt and ask user if they want to include AI players or not
                flag = int(input("Do you want to include AI players?\n[1] Yes [2] No: "))
                # Keep prompting user to input while flag is not 1 or 2
                while flag not in [1,2]:
                    print("Must only choose a number in range given.")
                    flag = int(input("Do you want to include AI players?\n[1] Yes [2] No: "))
                # Break the while loop when an appropriate statement inputted by user
                break
            # Print corresponding message while getting invalid statement or KeyboardInterrupt from user input
            except ValueError:
                print("You entered an invalid statement, please retry.")
            except KeyboardInterrupt:
                print("\nWhere do you think you are going?")
        
        # If flag is equal to 1, it means that the players want to include AI players
        if flag == 1:
            while True:
                # This try-except block is to prevent error while getting invalid input from user
                try:
                    # Prompt user to input number_of_AI_players
                    number_of_AI_players = int(input("How many AI players do you want to include in the game? "))
                    # Keep prompting while the number_of_AI_players is not in the range of number_of_players
                    while not (1 <= number_of_AI_players <= self.get_number_of_players()):
                        print(f"Sorry! The number of AI players must between 1 to {self.get_number_of_players()}.")
                        number_of_AI_players = int(input("How many AI players do you want to include in the game? "))
                    # Break the while loop when an appropriate statement inputted by user
                    break
                # Print corresponding message while getting invalid statement or KeyboardInterrupt from user input
                except ValueError:
                    print("You entered an invalid statement, please retry.")
                except KeyboardInterrupt:
                    print("\nWhere do you think you are going?")
            # Set the number_of_AI_players to the number_of_AI_players instance variable
            self.set_number_of_AI_players(number_of_AI_players)
            # Set the number_of_regular_players with the subtraction of total number_of_players and number_of_AI_players
            self.set_number_of_regular_players(self.get_number_of_players() - number_of_AI_players)
            # Print following message
            print(f"The game will include {self.get_number_of_AI_players()} AI player(s) and {self.get_number_of_regular_players()} regular player(s).\n\n")
        # Else, which means thatp players don't want to include AI players
        else:
            # Set number_of_regular_players with total number_of_players
            self.set_number_of_regular_players(self.get_number_of_players())
            # Print following message
            print(f"The game will include {self.get_number_of_regular_players()} regular players.\n\n")

    def prompt_winning_condition(self) -> None:
        """
        A method to get winning_condition from user.

        Arguments:
            - self
        
        Returns:
            - None.
        """
        while True:
            # This try-except block is to prevent error while getting invalid input from user
            try:
                # Prompt user to input the winning_condition
                winning_condition = int(input("What is the number of properties needed to win? "))
                # Keep prompting user to input while the winning_condition is not between 1 and 5
                while not (1 <= winning_condition <= 5):
                    print("Sorry! The winning condition must between 1 to 5.")
                    winning_condition = int(input("What is the number of properties needed to win? "))
                # Break the while loop when an appropriate statement inputted by user
                break
            # Print corresponding message while getting invalid statement or KeyboardInterrupt from user input
            except ValueError:
                print("You entered an invalid statement, please retry.")
            except KeyboardInterrupt:
                print("\nWhere do you think you are going?")
        print("\n")
        # Set the winning_condition to the winning_condition instance variable
        self.set_winning_condition(winning_condition)
    
    def initialise_board(self) -> None:
        """
        A method to initialise board.

        Arguments:  
            - self

        Returns:
            - None.
        """
        # Print following message
        print("Initialising board properties...\n\n")
        # Create a new PropertyGenerator instance
        board_properties = PropertyGenerator()
        # Pass the csv_data files to generate the board properties
        # board_properties.csv_to_properties(a.csv_data,a.delimiter)
        board_properties.csv_to_properties(b.csv_data,b.delimiter)
        # Use the property_location_generator method to randomly allocate locations to every properties
        board_properties.property_location_generator()
        # Set the properties and property_locations to Pypoly instance variables
        self.set_properties(board_properties.properties)
        self.set_property_location(board_properties.property_locations)  

    def initialise_players_details(self) -> None:
        """
        A method to initialise player details.

        Arguments:
            - self

        Returns:
            - None.
        """
        # Keep looping in the range of number_of_regular_players
        for player_index in range(self.get_number_of_regular_players()):
            # Prompt user to input name for the player
            name = input(f"What is player {player_index + 1}'s name? ").strip().capitalize()
            # Keep prompting user to input name if the name is in the player_names list
            while name in self.get_player_names():
                name = input(f"{name} is already taken, pick another name for player {player_index + 1}: ").strip().capitalize()
            # At this stage, the name should be different with every other names in player_names
            # Append the name in the player_names instance variable list
            self.set_player_names(name)

            # Print following message to ask player's move trait
            print(f"What is {name}'s move trait?")
        
            while True:
                # This try-except block is to prevent error while getting invalid input from user
                try:
                    # Prompt user to input the move_trait_index
                    move_trait_index = int(input("[0] Perpendicular [1] Diagonal [2] L: "))
                    # Keep looping while the move_trait_index is not in the range
                    while not (0 <= move_trait_index <= 2):
                        print("Must only choose a number in range given.")
                        move_trait_index = int(input("[0] Perpendicular [1] Diagonal [2] L: "))
                    # Break the while loop when an appropriate statement inputted by user
                    break
                # Print corresponding message while getting invalid statement or KeyboardInterrupt from user input
                except ValueError:
                    print("You entered an invalid statement, please retry.")
                except KeyboardInterrupt:
                    print("\nWhere do you think you are going?")
            
            # If move_trait_index equals to 0, means that the player chose to be a PerpendicularPlayer
            # Else if move_trait_index equals to 1, means that the player chose to be a DiagonalPlayer
            # Else, means that the player chose to be a LPlayer
            # Eitherwise, create corresponding Player child class instance
            if move_trait_index == 0:
                player = PerpendicularPlayer()
            elif move_trait_index == 1:
                player = DiagonalPlayer()
            else:
                player = LPlayer()
            
            # Set the player's name with name
            player.set_name(name)
            # Set the player's symbol with 1, 2, 3, etc.
            player.set_symbol(str(player_index + 1))
            # Randomly set the initial position of the player from the list of keys of property_locations
            player.set_position(random.choice(list(self.get_property_location().keys())))
            # Append the player instance to the players list 
            self.set_players(player)
            print("\n")
        
        # Keep looping in the range of number_of_AI_players
        for index in range(self.get_number_of_AI_players()):
            # Create a AIPlayer class instance
            ai_player = AIPlayer()
            # Set the name of the AI with AI_1, AI_2, etc.
            ai_player.set_name("AI_" + str(index + 1))
            # Set the symbol of the AI with a, b, c, etc.
            ai_player.set_symbol(chr(97 + index))
            # Randomly set the initial position of the ai_player from the list of keys of property_locations
            ai_player.set_position(random.choice(list(self.get_property_location().keys())))
            # Append the ai_player instance to the players list
            self.set_players(ai_player)     
    
    def prompt_choices(self, player: Player, flag: bool, purchased: bool) -> int:
        """
        A method to prompt user for a move decision.

        Arguments:
            - self
            - Object player
            - Boolean of flag
            - Boolean of purchased

        Returns:
            - Integer choice.
        """
        # Get the property instance by using player's current position tuple as key in the property_locations dictionary
        property = self.get_property_location()[player.get_position()]
        # Print following message
        print("Pick a choice: ")
        
        while True:
            # This try-except block is to prevent error while getting invalid input from user
            try:
                # If the flag is True and purchased is False
                # PS: flag is a boolean returned from the determine_action method
                if flag and purchased == False:
                    # Let user choose between 5 choices
                    choice = int(input("[1] Purchase property [2] Purchase hotel [3] Sell Property [4] Next Player [5] Quit Game: "))
                    # Keep prompting user to choose while the choice is not in range given
                    while not (1 <= choice <= 5):
                        print("Must only choose a number in range given.")
                        choice = int(input("[1] Purchase property [2] Purchase hotel [3] Sell Property [4] Next Player [5] Quit Game: "))
                # Otherwise, only let user to choose between 3 choices
                else:
                    choice = int(input("[3] Sell Property [4] Next Player [5] Quit Game: "))
                    # Keep prompting user to choose while the choice is not in range given
                    while not (3 <= choice <= 5):
                        print("Must only choose a number in range given.")
                        choice = int(input("[3] Sell Property [4] Next Player [5] Quit Game: "))
                # Break the while loop when an appropriate statement inputted by user
                break
            # Print corresponding message while getting invalid statement or KeyboardInterrupt from user input
            except ValueError:
                print("You entered an invalid statement, please retry.")
            except KeyboardInterrupt:
                print("\nWhere do you think you are going?")
        
        # If choice is equals to 5, it means that player wishes to quit the game
        if choice == 5:
            # Print following message
            print(f"Player {player} decided to quit the game :(\nThanks for playing {player}.")
            # Loop through every property in the player's properties_owned list
            for property in player.get_properties_owned():
                # Remove the property from the list
                player.get_properties_owned().remove(property)
                # Reset the owner of the property to "Bank" and the hotels_built to 0
                property.hotels_built = 0
                property.set_owner(Property.ORIGINAL_OWNER)
            # Remove the player from the players list
            self.get_players().remove(player)
            # Set the choice to 4, which indicates continuing to the next player
            choice = 4
        # Else if the choice is equals to 1, let player to try to purchase the property
        elif choice == 1:
            player.purchase_property(property)
        # Else if the choice is equals to 2, let player to try to purchase a hotel
        elif choice == 2:
            player.purchase_hotel(property)
        # Else if the choice is equals to 3, which means the player wishes to sell property
        elif choice == 3:
            # If the properties_owned list is empty
            if len(player.get_properties_owned()) == 0:
                # Print following message
                print(f"{player} don't have any property to sell.")
            # Else, which the properties_owned list is not empty
            else:
                # Print following message
                print("\n\nWhich property do you wish to sell? Pick a choice:")
                # Create an empty string
                prompt = ""
                # Loop through every index in the range of the length of properties_owned list
                for property_index in range(len(player.get_properties_owned())):
                    # Get the property instance in the properties_owned list using the property_index
                    property = player.get_properties_owned()[property_index]
                    # Concatenate prompt with the following string
                    prompt += f"[{property_index + 1}] {property} "
                # At the end, concatenate prompt with another choice "End" to let the player to not sell any property
                prompt += f"[{len(player.get_properties_owned()) + 1}] End: "

                while True:
                    # This try-except block is to prevent error while getting invalid input from user
                    try:
                        # Prompt user to input the which property to sell
                        sell_choice = int(input(prompt))
                        # Keep prompting while the sell_choice is not in range given
                        while not (1 <= sell_choice <= len(player.get_properties_owned()) + 1):
                            print("Must only choose a number in range given.")
                            sell_choice = int(input(prompt))
                        # Break the while loop when an appropriate statement inputted by user
                        break
                    # Print corresponding message while getting invalid statement or KeyboardInterrupt from user input
                    except ValueError:
                        print("You entered an invalid statement, please retry.")
                    except KeyboardInterrupt:
                        print("\nWhere do you think you are going?")
                # If the sell_choice is not "End"
                if sell_choice != len(player.get_properties_owned()) + 1:
                    # Let the player to sell the property chosen
                    player.sell_property(player.get_properties_owned()[sell_choice - 1])
                    print(f"Player {player} has ${player.get_fund()} left.")
        
        # Return the choice of the player
        return choice

    def play_turn(self, player: Player):
        """
        A method to prompt user to play his turn.
        
        Arguments:
            - self
            - Object player
        
        Returns:
            - None.
        """
        # Compute the row_size
        row_size = int(math.sqrt(len(self.get_properties())))
        # Print following message
        print(f"Player {player} is currently at location {player.get_position()}.")
        # Display the Pypoly board with the current position of the player and the positions of their valid moves
        player.display_moves(row_size, True)

        time.sleep(1)
        # Print following message
        print("\n\nPick one valid move")
        # Compute the valid_moves using the determine_valid_moves method
        valid_moves = player.determine_valid_moves(row_size)
        # Print every valid_moves in the terminal
        for index in range(len(valid_moves)):
            print(f"[{index}] - {valid_moves[index]}")

        while True:
            # This try-except block is to prevent error while getting invalid input from user
            try:
                # Prompt user to input choice
                choice = int(input())
                # Keep prompting while the choice in not in range given
                while not (0 <= choice < len(valid_moves)):
                    print("Must only choose a number in range given.")
                    choice = int(input())
                # Break the while loop when an appropriate statement inputted by user
                break
            # Print corresponding message while getting invalid statement or KeyboardInterrupt from user input
            except ValueError:
                print("You entered an invalid statement, please retry.")
            except KeyboardInterrupt:
                print("\nWhere do you think you are going?")
        
        # Set the player's new position with the choice chosen
        player.set_position(valid_moves[choice])
        print(f"\n\nPlayer {player} moved to {player.get_position()}.")
        # Display the Pypoly board with the current position of the player
        player.display_moves(row_size, False)
        time.sleep(1)

        # Set the choice to 0 and set the purchased to False
        # PS: purchased is a boolean which indicates if the player has purchased a property or hotel
        choice = 0
        purchased = False
        # Compute flag boolean using the determine_action method
        flag = player.determine_action(self.get_property_location())
        # Keep looping while the choice is not 4, which choice 4 indicates continuing the play turn to the next player
        while choice != 4:
            # Compute the previous_fund of the player before prompt_choices method
            previous_fund = player.get_fund()
            # Compute the choice using prompt_choices functiom
            choice = self.prompt_choices(player, flag, purchased)
            # If the choice is 1 or 2, and the player's new fund is lesser than the previous_fund
            # This means that the player has successfully purchased a property or a hotel
            if choice in [1,2] and player.get_fund() < previous_fund:
                # Set the purchased to True
                purchased = True
                # Display the player properties and their remaining fund
                print("\n\n--------------------------\n")
                time.sleep(1)
                player.display_player_properties()
                print(f"\nPlayer {player} has ${player.get_fund()} left.")
                print("\n--------------------------")
            print("\n")

    def AI_play_turn(self, ai_player: AIPlayer) -> None:
        """ 
        A method to stimulate an AI player turn. 

        Arguments: 
            - self
            - Object ai_player

        Returns: 
            - None. 
        """
        # Compute the row_size
        row_size = int(math.sqrt(len(self.get_properties())))
        # Print following message
        print(f"AIPlayer {ai_player} is currently at location {ai_player.get_position()}.")
        # Display the Pypoly board with the current position of the ai_player and the positions of their valid moves
        ai_player.display_moves(row_size, True)
        # Compute the valid_moves using the determine_valid_moves method
        valid_moves = ai_player.determine_valid_moves(row_size)
        # Compute the best_mobe using the ai_move method
        best_move = ai_player.ai_move(valid_moves, self.get_property_location())
        # Set the ai_player's position to the best_move
        ai_player.set_position(best_move)
        # Print following message
        n = 40
        for i in range(n):
            time.sleep(0.05)
            if i == 39:
                print("\n")
            elif(i + 1)%10 == 0:
                print(f"{ai_player} is thinking"+"."*i, end = "\r")
        print(f"\n\nAIPlayer {ai_player} moved to {ai_player.get_position()}.")
        # Display the Pypoly board with the current position of the ai_player
        ai_player.display_moves(row_size, False)
        time.sleep(1)
        # Let the ai choose whether to buy or build on the property
        ai_player.buy_or_build(best_move, self.get_property_location())
        # Display the ai_player properties and their remaining fund
        print("\n\n--------------------------\n")
        time.sleep(1)
        ai_player.display_player_properties()
        print(f"\nAIPlayer {ai_player} has ${ai_player.get_fund()} left.")
        print("\n--------------------------\n\n")

    def loop_turn(self) -> None:
        """
        A method to loop until a player meets the winning_condition.

        Arguments:
            - self
        
        Returns:
            None.
        """
        # Initialise the check_win with False
        check_win = False
        # Keep looping while the check_win is False
        while check_win == False:
            # If there are only one player left, break the while loop
            if len(self.get_players()) == 1:
                print(f"Game Over! {self.get_players()[0]} WINS!")
                break
            # Loop through every player in the players list
            for player in self.get_players():
                # If the player is AI, call the AI_play_turn method
                if "AI" in player.get_name():
                    self.AI_play_turn(player)
                # Else, call the regular play_turn method
                else:
                    self.play_turn(player)
                # Check if the player fulfills the winning_condition, if they do, set check_win to True and break the inner for loop
                if player.check_win(self.get_winning_condition()):
                    check_win = True
                    break
                time.sleep(1)

    def start(self) -> None:
        """
        A method to invoke methods in pypoly class to start the game.

        Arguments:
            - self

        Returns:
            - None.
        """
        self.print_welcome_messages()
        self.prompt_number_of_players()
        self.prompt_play_with_AI()
        self.prompt_winning_condition()
        self.initialise_board()
        time.sleep(1)
        self.initialise_players_details()
        self.loop_turn()

if __name__ == "__main__":
    game = PyPoly()
    game.start()
