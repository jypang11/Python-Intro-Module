from player import Player
 
class PerpendicularPlayer(Player):
    """ PerpendicularPlayer Class, a class which is inherited from the Player Class. """

    # Class variable
    BASE_MOVE_TRAIT = "Perpendicular"

    # Constructor
    def __init__(self) -> None:
        """ 
        Constructor of class PerpendicularPlayer and super class inherited from class Player. 
        Initialise instance variables. 
        
        Arguments:
            - self
        
        Returns:
            - None.
        """
        super().__init__()
        self.set_move_trait(self.BASE_MOVE_TRAIT)

    # Methods
    def determine_valid_moves(self, row_size: int) -> list[tuple]:
        """ 
        A method to determine all the valid moves that players can choose from and move to.
        
        Arguments:
            - self
            - Integer of row_size
        
        Returns:
            - List of tuple of location.
        """
        # Create an empty list to store the valid_moves
        valid_moves = []
        # Initialise self_row and self_column with the first and second coordinate of the player's position
        self_row = self.get_position()[0]
        self_column = self.get_position()[1]

        # Loop through every coordinate from (0, 0) to (row_size, row_size) and append valid moves to the valid_moves list
        for row in range(row_size):
            for column in range(row_size):
                if (row == self_row + 1 or row == self_row - 1) and column == self_column:
                    valid_moves.append((row, column))
                elif (column == self_column + 1 or column == self_column - 1) and row == self_row:
                    valid_moves.append((row, column))
        
        return valid_moves

    def display_moves(self, row_size: int, valid_flag: bool) -> None:
        """ 
        A method to display the current position of a player and the positions of their valid moves.
            
        Arguments:
            - self
            - Integer of row_size
            - Boolean of valid_flag
        
        Returns:
            - None.
        """
        # For example, with the row_size = 5, self.position = (2, 2), valid_flag = True
        # The codes below is to print out:
        # "    0   1   2   3   4  "
        # "  +---+---+---+---+---+"
        output = " "
        for row in range(row_size):
            output += "{:>4}".format(row)
        output += "\n  " + "+---" * row_size + "+"

        # The codes below is to print out:
        # "0 |   |   |   |   |   |"
        # "  +---+---+---+---+---+"
        # "1 |   |   | x |   |   |"
        # "  +---+---+---+---+---+"
        # "2 |   | x | P | x |   |"
        # "  +---+---+---+---+---+"
        # "3 |   |   | x |   |   |"
        # "  +---+---+---+---+---+"
        # "4 |   |   |   |   |   |"
        # "  +---+---+---+---+---+"
        for row in range(row_size):
            temp = f"\n{row} |"
            for column in range(row_size):
                if (row, column) in self.determine_valid_moves(row_size) and valid_flag == True:
                    temp += "{:^3}|".format("x")
                elif (row, column) == self.get_position():
                    temp += "{:^3}|".format(self.get_symbol())
                else:
                    temp += "   |"
            temp += "\n  " + "+---" * row_size + "+"
            output += temp
        
        print(output)


class DiagonalPlayer(Player):
    """ DiagonalPlayer Class, a class which is inherited from the Player Class. """
    
    BASE_MOVE_TRAIT = "Diagonal"

    # Constructor
    def __init__(self) -> None:
        """ 
        Constructor of class PerpendicularPlayer and super class inherited from class Player. 
        Initialise instance variables. 
        
        Arguments:
            - self
        
        Returns:
            - None.
        """
        super().__init__()
        self.set_move_trait(self.BASE_MOVE_TRAIT)

    # Methods
    def determine_valid_moves(self, row_size: int) -> list[tuple]:
        """ 
        A method to determine all the valid moves that players can choose from and move to.
            
        Arguments:
            - self
            - Integer of row_size
        
        Returns:
            - List of tuple of location.
        """
        # Create an empty list to store the valid_moves
        valid_moves = []
        # Initialise self_row and self_column with the first and second coordinate of the player's position
        self_row = self.get_position()[0]
        self_column = self.get_position()[1]

        # Loop through every coordinate from (0, 0) to (row_size, row_size) and append valid moves to the valid_moves list
        for row in range(row_size):
            for column in range(row_size):
                if (row == self_row + 1 or row == self_row - 1) and (column == self_column + 1 or column == self_column - 1):
                    valid_moves.append((row, column))
        return valid_moves

    def display_moves(self, row_size: int, valid_flag: bool) -> None:
        """ 
        A method to display the current position of a player and the positions of their valid moves.
            
        Arguments:
            - self
            - Integer of row_size
            - Boolean of valid_flag
        
        Returns:
            - None.
        """
        # For example, with the row_size = 4, self.position = (2, 1), valid_flag = True
        # The codes below is to print out:
        # "    0   1   2   3  "
        # "  +---+---+---+---+"
        output = " "
        for row in range(row_size):
            output += "{:>4}".format(row)
        output += "\n  " + "+---" * row_size + "+"

        # The codes below is to print out:
        # "0 |   |   |   |   |"
        # "  +---+---+---+---+"
        # "1 | x |   | x |   |"
        # "  +---+---+---+---+"
        # "2 |   | P |   |   |"
        # "  +---+---+---+---+"
        # "3 | x |   | x |   |"
        # "  +---+---+---+---+"
        for row in range(row_size):
            temp = f"\n{row} |"
            for column in range(row_size):
                if (row, column) in self.determine_valid_moves(row_size) and valid_flag == True:
                    temp += "{:^3}|".format("x")
                elif (row, column) == self.get_position():
                    temp += "{:^3}|".format(self.get_symbol())
                else:
                    temp += "   |"
            temp += "\n  " + "+---" * row_size + "+"
            output += temp
        
        print(output)
    
class LPlayer(Player):
    """ LPlayer Class, a class which is inherited from the Player Class. """
    
    BASE_MOVE_TRAIT = "L"

    # Constructor
    def __init__(self) -> None:
        """ 
        Constructor of class PerpendicularPlayer and super class inherited from class Player. 
        Initialise instance variables. 
        
        Arguments:
            - self
        
        Returns:
            - None.
        """
        super().__init__()
        self.set_move_trait(self.BASE_MOVE_TRAIT)

    # Methods
    def determine_valid_moves(self, row_size: int) -> list[tuple]:
        """ 
        A method to determine all the valid moves that players can choose from and move to.
        
        Arguments:
            - self
            - Integer of row_size
        
        Returns:
            - List of tuple of location.
        """
        # Create an empty list to store the valid_moves
        valid_moves = []
        # Initialise self_row and self_column with the first and second coordinate of the player's position
        self_row = self.get_position()[0]
        self_column = self.get_position()[1]

        # Loop through every coordinate from (0, 0) to (row_size, row_size) and append valid moves to the valid_moves list
        for row in range(row_size):
            for column in range(row_size):
                if (row == self_row + 2 or row == self_row - 2) and (column == self_column + 1 or column == self_column - 1):
                    valid_moves.append((row, column))
                elif (column == self_column + 2 or column == self_column - 2) and (row == self_row + 1 or row == self_row - 1):
                    valid_moves.append((row, column))
        
        return valid_moves

    def display_moves(self, row_size: int, valid_flag: bool) -> None:
        """ 
        A method to display the current position of a player and the positions of their valid moves.
            
        Arguments:
            - self
            - Integer of row_size
            - Boolean of valid_flag
        
        Returns:
            - None.
        """
        # For example, with the row_size = 5, self.position = (2, 2), valid_flag = True
        # The codes below is to print out:
        # "    0   1   2   3   4  "
        # "  +---+---+---+---+---+"
        output = " "
        for row in range(row_size):
            output += "{:>4}".format(row)
        output += "\n  " + "+---" * row_size + "+"

        # The codes below is to print out:
        # "0 |   | x |   | x |   |"
        # "  +---+---+---+---+---+"
        # "1 | x |   |   |   | x |"
        # "  +---+---+---+---+---+"
        # "2 |   |   | P |   |   |"
        # "  +---+---+---+---+---+"
        # "3 | x |   |   |   | x |"
        # "  +---+---+---+---+---+"
        # "4 |   | x |   | x |   |"
        # "  +---+---+---+---+---+"
        for row in range(row_size):
            temp = f"\n{row} |"
            for column in range(row_size):
                if (row, column) in self.determine_valid_moves(row_size) and valid_flag == True:
                    temp += "{:^3}|".format("x")
                elif (row, column) == self.get_position():
                    temp += "{:^3}|".format(self.get_symbol())
                else:
                    temp += "   |"
            temp += "\n  " + "+---" * row_size + "+"
            output += temp
        
        print(output)
