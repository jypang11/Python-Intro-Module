from property import Property
import math
import random

class Player:
    """ Player Class for representing every player of the pypoly board game. """

    # Class variable
    STARTING_FUND = 150
    
    # Constructor
    def __init__(self) -> None:
        """" 
        Constructor of class Player. 
        Initialise instance variables.

        Arguments:
            - self

        Returns:
            - None.
        """
        self.name = ""
        self.symbol = ""
        self.fund = Player.STARTING_FUND
        self.move_trait = ""
        self.position = (None, None)
        self.properties_owned = []
    
    # Accessors (Getters)
    def get_name(self) -> str:
        """
        A method to get instance variable name of the object. 

        Arguments:
            - self
        
        Returns: 
            - String of instance variable name of the object. 
        """
        return self.name

    def get_symbol(self) -> str:
        """ 
        A method to get instance variable symbol of the object. 
        
        Arguments:
            - self

        Returns:
            - String of instance variable symbol of the object. 
        """
        return self.symbol

    def get_fund(self) -> int:
        """ 
        A method to get instance variable fund of the object. 

        Arguments:
            - self

        Returns:
            - Integer of instance variable fund of the object. 
        """
        return self.fund

    def get_properties_owned(self) -> list:
        """ 
        A method to get instance variable properties_owned of the object. 

        Arguments:
            - self

        Returns: 
            - List of instance variable propertirs owned of the object. """        
        return self.properties_owned

    def get_position(self) -> tuple:
        """ 
        A method to get instance variable position of the object. 

        Arguments:
            - self

        Returns: 
            - Tuple of instance variable position of the object. 
        """
        return self.position

    def get_move_trait(self) -> str:
        """ 
        A method to get instance variable move trait of the object. 

        Arguments:
            - self

        Returns: 
            - String instance variable move trait of the object. 
        """
        return self.move_trait

    # Mutators (Setters)
    def set_name(self, name: str) -> None:
        """ 
        A method to set instance variable name of the object. 

        Arguments:
            - self
            - String of name

        Returns: 
            - None. 
        """
        self.name = name

    def set_symbol(self, symbol: str) -> None:        
        """ 
        A method to set instance variable symbol of the object. 

        Arguments:
            - self
            - String of symbol

        Returns: 
            - None. 
        """
        self.symbol = symbol

    def set_position(self, position: tuple) -> None: 
        """ 
        A method to set instance variable position of the object. 

        Arguments:
            - self
            - Tuple of position

        Returns: 
            - None.
        """    
        self.position = position

    def set_properties_owned(self, property: Property) -> None:
        """ 
        A method to set instance variable properties_owned of the object. 

        Arguments:
            - self
            - Object property

        Returns: 
            - None. 
        """
        self.properties_owned.append(property)

    def set_move_trait(self, move_trait: str) -> None:
        """ 
        A method to set instance variable move_trait of the object. 

        Arguments:
            - self
            - String of move_trait

        Returns: 
            - None.
        """
        self.move_trait = move_trait

    # Methods
    def add_fund(self, amount: int) -> None:
        """ 
        A method to add that amount of money from the player's fund.

        Arguments:
            - self
            - Integer of amount

        Returns: 
            - None. 
        """
        self.fund += amount
    
    def reduce_fund(self, amount: int) -> None:
        """ 
        A method to reduce that amount of money from the player's fund.

        Arguments:
            - self
            - Integer of amount
        
        Returns: 
            - None. 
        """
        self.fund -= amount

    def __str__(self) -> str:
        """ A magic method to use print() or str() on our Player objects.
            Return : Instance variable name of the object."""
        return self.get_name()

    def __repr__(self) -> str:
        """ Calling the magic method to avoid error in error
            Return : Instance variable inside the method __str__()."""
        return self.__str__()

    def purchase_property(self, property: Property) -> None:
        """
        A method to purchase property by reducing player funds and set corresponding properties's owner to the player with conditions.

        Arguments:
            - self
            - Object property

        Returns:
            - None.
        """
        # If the property is already owned by the player, print corresponding message
        if property in self.get_properties_owned():
            print(f"{self} has already owned {property}.")
        # If the player can't afford to purchase the property (which their fund is lesser than the property cost), print corresponding message
        elif self.get_fund() < property.get_property_cost():
            print(f"{self} cannot purchase {property} due to insufficient funds.")
        # Else, which the property is not owned by the player and the player can afford to purchase the property
        else:
            # Reduce the amount of the property cost from the player fund
            self.reduce_fund(property.get_property_cost())
            # Append the properties_owned list with the Property instance
            self.set_properties_owned(property)
            # Set the owner of the property with the Player instance
            property.set_owner(self)
            # Print corresponding message
            print(f"{self} purchased {property}.")

    def purchase_hotel(self, property: Property) -> None:
        """
        A method to purchase hotel by reducing player funds and increasing hotel built by 1 with conditions.

        Arguments:
            - self
            - Object property

        Returns:
            - None.
        """
        # print(self.get_fund())
        # If the property is not owned by the player, print corresponding message
        if property not in self.get_properties_owned():
            print(f"{self} must purchase {property} before constructing a hotel.")
        # Check if the player could afford to construct a hotel on the property, if couldn't, print corresponding message
        elif self.get_fund() < property.get_hotel_cost():
            print(f"{self} cannot construct a hotel on {property} due to insufficient funds.")
        # Else, which the player owns the property and could afford to construct a hotel
        else:
            # If the hotels_built on the property is lesser than 2, means that player can certainly contruct a hotel
            if property.get_hotels_built() < 2:
                # Reduce the fund of the player with the hotel_cost and construct a hotel
                self.reduce_fund(property.get_hotel_cost())
                property.construct_hotel()

    def sell_property(self, property: Property) -> None:
        """
        A method to purchase property by adding player funds and set corresponding properties's owner to the ORIGINAL_OWNER with conditions.

        Arguments:
            - self
            - Object property

        Returns:
            - None.
        """
        # If the property is not owned by the player, print corresponding message
        if property not in self.get_properties_owned():
            print(f"{self} cannot sell {property} because {self} is not the owner.")
        # Else, which the player owns the property
        else:
            # Compute the sold_income by adding the property_cost and the product of hotels_built and hotel_cost
            sold_income = property.get_property_cost() + property.get_hotels_built() * property.get_hotel_cost()
            # Add the sold_income to the fund of the player
            self.add_fund(sold_income)
            # Remove the Property instance from the properties_owned list of the player
            self.get_properties_owned().remove(property)
            # Set the owner of the Property instance back to the ORIGINAL_OWNER, which is Bank
            property.set_owner(Property.ORIGINAL_OWNER)
            # Reset the hotels_built of the property to 0
            property.hotels_built = 0
            # property.set_hotels_built(0)
            # Print corresponding message
            print(f"{self} sold {property} for ${sold_income}.")
            
    def display_player_properties(self) -> None:
        """
        A method to display player properties owned according to the colour group.

        Arguments:
            - self

        Returns:
            - None.
        """
        # Create variable total_properties_value to represent the total value of properties owned by player, it is initialised with 0
        total_properties_value = 0
        # Create variable total_hotels_value to represent the total value of hotels constructed by player, it is initialised with 0
        total_hotels_value = 0
        # Loop through every property colour_group in COLOUR_GROUPS
        for colour_group in Property.COLOUR_GROUPS:
            # Loop through every property in the properties_owned list of the player
            for property in self.get_properties_owned():
                # If the property's colour_group is the same as the colour_group currently looping in the outer for loop
                if property.get_colour_group() == colour_group:
                    # Print out the colour_group name with uppercase
                    print(colour_group.upper())
                    break
            # Create a property_count variable to count how many property owned by player is the same as the current colour_group, it is used as property indexing
            property_count = 0
            # Again, loop through every property in the properties_owned list of the player
            for property in self.get_properties_owned():
                # If the property's colour_group is the same as the colour_group currently looping in the outer for loop
                if property.get_colour_group() == colour_group:
                    # Increment the property_count by 1
                    property_count += 1
                    # print corresponding message
                    print(f"{property_count}. ${property.get_property_cost()} {property} (${property.get_hotel_cost()} Hotels x {property.get_hotels_built()})")
                    # Add the corresponding values to the respective total value variables
                    total_properties_value += property.get_property_cost()
                    total_hotels_value += property.get_hotel_cost() * property.get_hotels_built()
        # Finally, print out the total value of properties owned and hotels constructed by the player
        print(f"TOTAL\n${total_properties_value} worth of properties\n${total_hotels_value} worth of hotels")

    def check_win(self, winning_condition: int) -> bool:
        """
        A method to check if the player meets the winning_condition.

        Arguments:
            - self
            - Integer of winning_condition

        Returns:
            - Boolean. 
        """
        # Loop through every property colour_group in COLOUR_GROUPS
        for colour_group in Property.COLOUR_GROUPS:
            # Declare and initialise winning_index with 0 to indicate how many property owned by player satisfies the winning condition
            winning_index = 0
            # To satisfies the winning condition, the player must purchase winning_condition number of properties and build at least one hotel on each property
            # Loop through every property in the properties_owned list of the player
            for property in self.get_properties_owned():
                # If the property's colour_group is the same as the colour_group currently looping in the outer for loop
                # and the property has at least one hotel built on it
                if property.get_colour_group() == colour_group and property.get_hotels_built() > 0:
                    # Increment the winning_index by 1
                    winning_index += 1
            # Finally, if the winning_index is equal to winning_condition
            if winning_index == winning_condition:
                # print corresponding message and return True
                print(f"Game Over! {self} WINS!")
                return True
        # Otherwise, player cannot purchase property or construct hotels on that property, return False
        return False


    def pay_rent(self, property: Property) -> None:
        """
        A method to pay rent to the owner if player lands on a property that was previously purchased by another player.

        Arguments:
            - self
            - Object property

        Returns:
            - None.
        """
        # Compute the total rent price
        # Firstly, get the rent_price of the property
        # Then, multiply the rent_price with 1 + 0.2 * hotels_built, which means for every hotel built on The property, the rent price will increase by 20 %
        # Finally, round up the value to the nearest integer by using the math ceiling function
        rent = math.ceil(property.get_rent_price() * (1 + 0.2 * property.get_hotels_built()))

        # If the player cannot afford to pay rent (which the fund of the player is lesser than the rent) and has no property owned
        if self.get_fund() < rent and self.get_properties_owned() == []:
            # Set the paid amount with all the fund of the player
            paid = self.get_fund()
            # Give the paid amount to the property owner
            property.get_owner().add_fund(paid)
            # Reduce the fund of the original player with paid amount (which the fund is reduced to 0)
            self.reduce_fund(paid)
            # Print corresponding message
            print(f"{self} paid ${paid} as a rental charge to {property.get_owner()} and has ${self.get_fund()} left.")
        # If the player cannot afford to pay rent (which the fund of the player is lesser than the rent) and has property owned
        elif self.get_fund() < rent and len(self.get_properties_owned()) > 0:
            # Declare and initialise the lowest_value_property to None
            lowest_value_property = None
            # If the player only owns 1 property, straightly set that property to lowest_value_property
            if len(self.get_properties_owned()) == 1:
                lowest_value_property = self.get_properties_owned()[0]
            # Else, which the player has more than 1 property owned
            else:
                # Set the lowest_value_property to the first Property instance in the properties_owned list
                lowest_value_property = self.get_properties_owned()[0]
                # Compute the value of the lowest_value_property by adding the property_cost with hotel_cost * hotels_built
                lowest_value = lowest_value_property.get_property_cost() + lowest_value_property.get_hotel_cost() * lowest_value_property.get_hotels_built()
                # Loop through every Property instance from index 1 onwards
                for self_property in self.get_properties_owned()[1:]:
                    # Compute the value of the property
                    value = self_property.get_property_cost() + self_property.get_hotel_cost() * self_property.get_hotels_built()
                    # If the value is lesser than the lowest_value
                    if value < lowest_value:
                        # Update the lowest_value with the current value of the property
                        lowest_value = value
                        # Update the lowest_value_property with the current property
                        lowest_value_property = self_property
            # Print corresponding message
            print(f"{self} does not have sufficient funds. {self} gives {lowest_value_property} to {property.get_owner()} instead.")
            # Remove the lowest_value_property from the player properties_owned list
            self.get_properties_owned().remove(lowest_value_property)
            # Append the lowest_value_property to the properties_owned list of the property owner
            property.get_owner().get_properties_owned().append(lowest_value_property)
            # Set the owner of the lowest_value_property to the property owner
            lowest_value_property.set_owner(property.get_owner())
        # Else, which the player can afford to pay rent
        else:
            # Reduce the fund of the player
            self.reduce_fund(rent)
            # Add the rent amount to the property owner
            property.get_owner().add_fund(rent)
            # Print corresponding message
            print(f"{self} paid ${rent} as a rental charge to {property.get_owner()} and has ${self.get_fund()} left.")
    
    def determine_action(self, property_locations: dict) -> bool:
        """
        A method to check what action would be appropriate for the player to take next. 

        Arguments:
            - self
            - Dictionary of property_locations

        Returns:
            - Boolean.
        """
        # Compute property using the property_locations dictionary with the player's position as key
        property = property_locations[self.get_position()]
        
        # If the property is "Penalty"
        if property.get_property_name() == "Penalty":
            # Randomly generate the penalty amount by multiplying the player's fund with random value between 0.05 and 0.3
            # Round up the value to the nearest integer
            penalty = math.ceil(self.get_fund() * random.uniform(0.05, 0.3))
            # Reduce penalty amount to the fund of the player
            self.reduce_fund(penalty)
            # Print corresponding message
            print(f"{self} landed on Penalty and has been fined ${penalty}.")
        # Else if the property is "Reward"
        elif property.get_property_name() == "Reward":
            # Randomly generate the reward amount between 30 and 150 (included)
            reward = random.randint(30, 150)
            # Add the reward amount to the fund of the player
            self.add_fund(reward)
            # Print corresponding message
            print(f"{self} landed on Reward and has been rewarded ${reward}.")
        # Else if the property owner is "Bank"
        # PS: The property is not possible to be "Reward" or "Penalty" here
        # which means that this property can be purchased by player, return True
        elif property.get_owner() == "Bank":
            # Print corresponding message
            print(f"{self} landed on {property}.")
            return True
        # Else if the property owner is player themselves
        elif property.get_owner() == self:
            # Print corresponding message
            print(f"{self} landed on {property}, a property that they own.")
            # If the hotels_built on the property is lesser than 2, means that player can build hotel(s) on it, return True
            if property.get_hotels_built() < 2:
                return True
        # Else if the property is not owned by player themselves
        # PS: The property is not possible to be owned by "Bank" here
        # which means that the property is owned by other player
        elif property.get_owner() != self:
            # Print corresponding message
            print(f"{self} landed on {property}, a property owned by {property.get_owner()}.")
            # execute the pay_rent function
            self.pay_rent(property)
            
        # Otherwise, player cannot purchase property or construct hotels on that property, return False
        return False
