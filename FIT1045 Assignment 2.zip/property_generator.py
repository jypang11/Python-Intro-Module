from property import Property
import random
import math

class PropertyGenerator:
    """ PropertyGenerator Class to generate every property on the Pypoly board game. """
    
    # Contructor
    def __init__(self) -> None:
        """ 
        Constructor of class PropertyGenerator.
        Initialise instance variables.

        Arguments: 
            - self 

        Returns:
            - None
        """
        self.properties = []
        self.property_locations = {}
        self.number_of_locations = 0

    def get_property_locations(self):
        return self.property_locations
        
    # Methods
    def csv_to_properties(self, data: str, delimiter: str) -> None:
        """ 
        A method to read through the csv data, create property object and store them inside properties list. 

        Arguments: 
            - self
            - String data from property_csv_data_a or property_csv_data_b
            - String delimiter from property_csv_data_a or property_csv_data_b

        Returns: 
            - None. 
        """
        # Split the first row in csv_data with delimiter to compute a list of column data fields and store the list inside first_row
        first_row = data[0].split(delimiter)

        # Use a for loop to find the index of every column data fields and store them into corresponding index variables
        for index in range(len(first_row)):
            if first_row[index] == "property_name":
                property_name_index = index
            elif first_row[index] == "property_cost":
                property_cost_index = index
            elif first_row[index] == "hotel_cost":
                hotel_cost_index = index
            elif first_row[index] == "rent_price":
                rent_price_index = index
            elif first_row[index] == "colour_group":
                colour_group_index = index

        # This for loop will loop through the csv_data from the second to the last row to generate Property instances and store them inside properties list
        for element in data[1:]:
            # Generate the property_data list by splitting the row element with delimiter
            property_data = element.split(delimiter)

            # Use the property_data list and column data fields index to compute every instance variables of Property
            property_name = property_data[property_name_index]
            property_cost = int(property_data[property_cost_index])
            hotel_cost = int(property_data[hotel_cost_index])
            rent_price = int(property_data[rent_price_index])
            colour_group = property_data[colour_group_index]
            
            # Generate Property instance using the Property Class constructor and store them inside the properties list
            self.properties.append(Property(property_name, property_cost, hotel_cost, rent_price, colour_group))
            
    def property_location_generator(self) -> None:
        """ 
        A method to randomly generate property location in the dictionary property_locations.

        Arguments: 
            - self

        Returns: 
            - None. 
        """
        # Generate the length (which is the row and column size) of the properties board.
        # Firstly, add the total number of properties with 4 since we need to include at least 4 chance grids
        # Then, find the square root of the value and take the ceiling value of it
        # Finally, cast the value to int to get the length
        length = int(math.ceil(math.sqrt(len(self.properties)+4)))
        # The total number_of_locations is the square of the length and it will be the nearest square number of properties
        self.number_of_locations = length ** 2

        # Keep looping while the total number of properties is lesser than the desire number_of_locations
        while len(self.properties) < self.number_of_locations:
            # Since we need to have rougly equal amount of "Reward" and "Penalty", we can do that by adding them alternatively to the properties list
            # Create a empty string
            unoccupied = ""
            # If the last Property instance's name is "Reward", assign "Penalty" to unoccupied
            if self.properties[-1].get_property_name() == "Reward":
                unoccupied = "Penalty"
            # Else (which is possibly be "Penalty" or some Property name), assign "Reward" to unoccupied
            else:
                unoccupied = "Reward"
            # Generate the "Reward" or "Penalty" Property instance using Property Class constructor and store them inside the properties list
            self.properties.append(Property(unoccupied, None, None, None, None))

        # Create a copy of the properties list
        properties_copy = self.properties[:]
        # Loop through every (row, column) from (0, 0) to (length, length), which has total number_of_locations times of loops
        for row in range(length):
            for column in range(length):
                # Randomly choose one index from the properties_copy list to choose one random Property instance
                index = random.randrange(len(properties_copy))
                # Store the random Property instance inside element
                element = properties_copy[index]
                # Set the location of the Property instance with the corresponding (row, column) tuple
                self.properties[index].set_location((row, column))
                # Using the (row, column) coordinate as the keys, store the Property instances as values in the property_locations dictionary
                self.property_locations[(row, column)] = element
                # Remove the Property instance from the properties_copy list
                properties_copy.remove(element)
