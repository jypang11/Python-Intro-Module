class Property:
    """ Property Class for representing every property on the pypoly game. """

    # Class variables
    ORIGINAL_OWNER = "Bank"
    COLOUR_GROUPS = ["Blue", "Green", "Red", "Yellow"]

    # Constructor
    def __init__(self, property_name: str, property_cost: int, hotel_cost: int, rent_price: int, colour_group: str) -> None:
        self.property_name = property_name.title()
        self.property_cost = property_cost
        self.hotel_cost = hotel_cost
        self.rent_price = rent_price
        self.colour_group = colour_group
        self.hotels_built = 0
        self.location = (None, None)
        self.owner = self.ORIGINAL_OWNER

    # Accessors (Getters)
    def get_property_name(self) -> str:
        return self.property_name

    def get_property_cost(self) -> int:
        return self.property_cost

    def get_hotel_cost(self) -> int:
        return self.hotel_cost

    def get_hotels_built(self) -> int:
        return self.hotels_built

    def get_rent_price(self) -> int:
        return self.rent_price

    def get_colour_group(self) -> str:
        return self.colour_group

    def get_owner(self) -> object:
        return self.owner

    def get_location(self) -> tuple:
        return self.location

    # Mutators (Setters)
    def set_hotels_built(self, hotels_built: int) -> None:
        self.hotels_built = hotels_built

    def set_owner(self, owner: object) -> None:
        self.owner = owner

    def set_rent_price(self, rent_price: int) -> None:
        self.rent_price = rent_price

    def set_location(self, location: tuple) -> None:
        self.location = location

    # Methods
    def construct_hotel(self) -> None:
        """
        Check if it is able to construct a hotel on the Property instance, and print corresponding messages.

        Arguments:
            - self

        Returns:
            - True: If a hotel is constructed.
            - False: If no hotel is constructed.
        """
        # If the Property instance does not has any hotels built on it, build 1 hotel and print corresponding message
        if self.get_hotels_built() == 0:
            self.hotels_built += 1
            print(f"1 hotel has been built on {self}.")
        # Else if there are only 1 hotel has been built on the Property instance, build another hotel and print corresponding message
        elif self.get_hotels_built() == 1:
            self.hotels_built += 1
            print(f"2 hotels have been built on {self}.")
        # Else, which means there are already 2 hotels have been built on the Property instance, print corresponding message
        else:
            print(f"The maximum number of hotels have been built on {self}.")

    def __str__(self) -> str:
        return self.get_property_name()

    def __repr__(self) -> str:
        return self.__str__()
